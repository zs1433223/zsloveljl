"""
地图点位路由
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlmodel import Session, select
from typing import List, Optional
import json

from database import get_db
from models.map_point import MapPoint
from schemas import MapPointCreate, MapPointUpdate, MapPointResponse

router = APIRouter(tags=["地图点位"])


@router.get("", response_model=List[MapPointResponse])
def list_map_points(
    city: Optional[str] = None,
    province: Optional[str] = None,
    point_type: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """获取地图点位列表（支持按城市/省份/类型筛选）"""
    query = select(MapPoint).where(MapPoint.status == "published")

    if city:
        query = query.where(MapPoint.city == city)
    if province:
        query = query.where(MapPoint.province == province)
    if point_type:
        query = query.where(MapPoint.point_type == point_type)

    query = query.order_by(MapPoint.sort_order)
    items = db.exec(query).all()

    results = []
    for item in items:
        data = MapPointResponse(
            id=item.id,
            name=item.name,
            description=item.description,
            longitude=item.longitude,
            latitude=item.latitude,
            city=item.city,
            province=item.province,
            country=item.country,
            point_type=item.point_type,
            cover_image=item.cover_image,
            photos=json.loads(item.photos or "[]"),
            videos=json.loads(item.videos or "[]"),
            sort_order=item.sort_order,
            status=item.status,
            created_at=item.created_at,
            updated_at=item.updated_at,
        )
        results.append(data)
    return results


@router.get("/{point_id}", response_model=MapPointResponse)
def get_map_point(point_id: int, db: Session = Depends(get_db)):
    """获取单个地图点位详情"""
    item = db.get(MapPoint, point_id)
    if not item:
        raise HTTPException(status_code=404, detail="点位不存在")

    return MapPointResponse(
        id=item.id,
        name=item.name,
        description=item.description,
        longitude=item.longitude,
        latitude=item.latitude,
        city=item.city,
        province=item.province,
        country=item.country,
        point_type=item.point_type,
        cover_image=item.cover_image,
        photos=json.loads(item.photos or "[]"),
        videos=json.loads(item.videos or "[]"),
        sort_order=item.sort_order,
        status=item.status,
        created_at=item.created_at,
        updated_at=item.updated_at,
    )


@router.post("", response_model=MapPointResponse)
def create_map_point(data: MapPointCreate, db: Session = Depends(get_db)):
    """创建地图点位（仅管理员）"""
    item = MapPoint(
        name=data.name,
        description=data.description,
        longitude=data.longitude,
        latitude=data.latitude,
        city=data.city,
        province=data.province,
        country=data.country,
        point_type=data.point_type,
        cover_image=data.cover_image,
        photos=json.dumps(data.photos),
        videos=json.dumps(data.videos),
        sort_order=data.sort_order,
        status=data.status,
    )
    db.add(item)
    db.commit()
    db.refresh(item)

    return MapPointResponse(
        id=item.id,
        name=item.name,
        description=item.description,
        longitude=item.longitude,
        latitude=item.latitude,
        city=item.city,
        province=item.province,
        country=item.country,
        point_type=item.point_type,
        cover_image=item.cover_image,
        photos=data.photos,
        videos=data.videos,
        sort_order=item.sort_order,
        status=item.status,
        created_at=item.created_at,
        updated_at=item.updated_at,
    )


@router.put("/{point_id}", response_model=MapPointResponse)
def update_map_point(point_id: int, data: MapPointUpdate, db: Session = Depends(get_db)):
    """更新地图点位（仅管理员）"""
    item = db.get(MapPoint, point_id)
    if not item:
        raise HTTPException(status_code=404, detail="点位不存在")

    update_data = data.model_dump(exclude_unset=True)
    if "photos" in update_data:
        update_data["photos"] = json.dumps(update_data["photos"])
    if "videos" in update_data:
        update_data["videos"] = json.dumps(update_data["videos"])

    for key, value in update_data.items():
        setattr(item, key, value)

    db.add(item)
    db.commit()
    db.refresh(item)

    return MapPointResponse(
        id=item.id,
        name=item.name,
        description=item.description,
        longitude=item.longitude,
        latitude=item.latitude,
        city=item.city,
        province=item.province,
        country=item.country,
        point_type=item.point_type,
        cover_image=item.cover_image,
        photos=json.loads(item.photos or "[]"),
        videos=json.loads(item.videos or "[]"),
        sort_order=item.sort_order,
        status=item.status,
        created_at=item.created_at,
        updated_at=item.updated_at,
    )


@router.delete("/{point_id}")
def delete_map_point(point_id: int, db: Session = Depends(get_db)):
    """删除地图点位（仅管理员）"""
    item = db.get(MapPoint, point_id)
    if not item:
        raise HTTPException(status_code=404, detail="点位不存在")
    db.delete(item)
    db.commit()
    return {"message": "点位已删除"}
