import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/login',
      name: 'Login',
      component: () => import('@/views/Login.vue'),
    },
    {
      path: '/',
      component: () => import('@/views/Layout.vue'),
      redirect: '/dashboard',
      children: [
        {
          path: 'dashboard',
          name: 'Dashboard',
          component: () => import('@/views/Dashboard.vue'),
          meta: { title: '仪表盘' },
        },
        {
          path: 'users',
          name: 'Users',
          component: () => import('@/views/Users.vue'),
          meta: { title: '用户管理' },
        },
        {
          path: 'relationship',
          name: 'Relationship',
          component: () => import('@/views/Relationship.vue'),
          meta: { title: '关系管理' },
        },
        {
          path: 'records',
          name: 'Records',
          component: () => import('@/views/Records.vue'),
          meta: { title: '恋爱记录' },
        },
        {
          path: 'map-points',
          name: 'MapPoints',
          component: () => import('@/views/MapPoints.vue'),
          meta: { title: '地图点位' },
        },
        {
          path: 'map-points/create',
          name: 'MapPointCreate',
          component: () => import('@/views/MapPointForm.vue'),
          meta: { title: '新建地图点位' },
        },
        {
          path: 'map-points/:id/edit',
          name: 'MapPointEdit',
          component: () => import('@/views/MapPointForm.vue'),
          meta: { title: '编辑地图点位' },
        },
        {
          path: 'milestones',
          name: 'Milestones',
          component: () => import('@/views/Milestones.vue'),
          meta: { title: '里程碑' },
        },
        {
          path: 'milestones/create',
          name: 'MilestoneCreate',
          component: () => import('@/views/MilestoneForm.vue'),
          meta: { title: '新建里程碑' },
        },
        {
          path: 'milestones/:id/edit',
          name: 'MilestoneEdit',
          component: () => import('@/views/MilestoneForm.vue'),
          meta: { title: '编辑里程碑' },
        },
      ],
    },
  ],
})

export default router
