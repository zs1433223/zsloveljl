/**
 * LoveRecordList 组件
 * 恋爱记录列表页
 */
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { getLoveRecords, LoveRecord } from '@/lib/api';
import Image from 'next/image';

export default function LoveRecordList() {
  const [records, setRecords] = useState<LoveRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const total = 999; // 假设总数

  useEffect(() => {
    setLoading(true);
    getLoveRecords({ page, per_page: 9 })
      .then((res) => setRecords(res.items))
      .finally(() => setLoading(false));
  }, [page]);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="glass p-6 animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
            <div className="h-3 bg-gray-100 rounded w-full mb-2"></div>
            <div className="h-3 bg-gray-100 rounded w-2/3"></div>
          </div>
        ))}
      </div>
    );
  }

  if (records.length === 0) {
    return (
      <div className="text-center py-12 text-gray-400">
        <p className="text-xl">还没有恋爱记录哦~</p>
        <p className="mt-2">等待管理员创建第一条记录</p>
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {records.map((record) => (
          <Link
            key={record.id}
            href={`/records/${record.id}`}
            className="glass p-6 hover:shadow-lg transition-shadow animate-fade-in"
          >
            {record.media?.[0]?.media_url && (
              <div className="relative h-48 rounded-lg overflow-hidden mb-4">
                <Image
                  src={record.media[0].media_url}
                  alt={record.title}
                  fill
                  className="object-cover"
                />
                {record.is_private && (
                  <div className="absolute top-2 right-2 bg-black/50 text-white px-2 py-1 rounded text-xs">
                    🔒 私密
                  </div>
                )}
              </div>
            )}
            <h3 className="text-xl font-bold text-gray-800 mb-2">
              {record.title}
            </h3>
            <p className="text-gray-600 text-sm line-clamp-2 mb-3">
              {record.content || '暂无描述'}
            </p>
            <div className="flex items-center justify-between text-sm text-gray-500">
              <span>{new Date(record.record_date).toLocaleDateString('zh-CN')}</span>
              <div className="flex gap-3">
                <span>👁 {record.views}</span>
                <span>❤️ {record.likes}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* 分页 */}
      {total > 9 && (
        <div className="flex justify-center gap-2 mt-8">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-4 py-2 rounded-lg bg-white/50 disabled:opacity-50"
          >
            上一页
          </button>
          <span className="px-4 py-2">{page}</span>
          <button
            onClick={() => setPage((p) => p + 1)}
            disabled={page >= Math.ceil(total / 9)}
            className="px-4 py-2 rounded-lg bg-white/50 disabled:opacity-50"
          >
            下一页
          </button>
        </div>
      )}
    </>
  );
}
