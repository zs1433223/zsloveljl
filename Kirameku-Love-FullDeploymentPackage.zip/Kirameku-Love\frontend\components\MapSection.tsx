/**
 * MapSection 组件
 * 高德地图 - 中国地图、城市点位、卫星/玻璃效果样式
 */
'use client';

import { useEffect, useRef, useState } from 'react';
import AMapLoader from '@amap/amap-jsapi-loader';

interface MapPoint {
  id: number;
  name: string;
  description: string;
  longitude: number;
  latitude: number;
  city: string;
  province: string;
  cover_image: string;
  photos: string[];
}

let AMap: any = null;

export default function MapSection() {
  const mapRef = useRef<HTMLDivElement>(null);
  const [mapInstance, setMapInstance] = useState<any>(null);
  const [markers, setMarkers] = useState<any[]>([]);
  const [selectedPoint, setSelectedPoint] = useState<MapPoint | null>(null);
  const [loading, setLoading] = useState(true);
  const [mapStyle, setMapStyle] = useState<'normal' | 'satellite' | 'glass'>('normal');

  useEffect(() => {
    const loadMap = async () => {
      try {
        AMap = await AMapLoader.load({
          key: process.env.NEXT_PUBLIC_AMAP_KEY || '',
          version: '2.0',
          plugins: ['AMap.Marker', 'AMap.InfoWindow'],
        });

        if (!mapRef.current) return;

        const map = new AMap.Map(mapRef.current, {
          center: [104.195397, 35.86166], // 中国中心
          zoom: 4,
          mapStyle: mapStyle === 'satellite' ? 'amap://styles/dark' : 
                    mapStyle === 'glass' ? 'amap://styles/glass' : 'amap://styles/normal',
        });

        setMapInstance(map);
        setLoading(false);

        // 加载地图点位
        const points = await fetch('/api/map-points/').then(res => res.json());
        
        const markerList = points.map((point: MapPoint) => {
          const marker = new AMap.Marker({
            position: [point.longitude, point.latitude],
            title: point.name,
            content: `
              <div class="custom-marker" style="cursor: pointer;">
                <div class="w-8 h-8 rounded-full bg-rose-500 border-2 border-white flex items-center justify-center text-white text-xs">
                  ❤
                </div>
              </div>
            `,
            offset: new AMap.Pixel(-16, -16),
          });

          marker.on('click', () => {
            setSelectedPoint(point);
            showInfoWindow(map, marker, point);
          });

          marker.setMap(map);
          return marker;
        });

        setMarkers(markerList);
      } catch (error) {
        console.error('地图加载失败:', error);
        setLoading(false);
      }
    };

    loadMap();
  }, []);

  const showInfoWindow = (map: any, marker: any, point: MapPoint) => {
    const infoContent = `
      <div style="padding: 12px; min-width: 200px;">
        <h3 style="font-size: 16px; font-weight: bold; margin-bottom: 8px;">${point.name}</h3>
        ${point.cover_image ? `
          <img src="${point.cover_image}" style="width: 100%; height: 120px; object-fit: cover; border-radius: 8px; margin-bottom: 8px;" />
        ` : ''}
        <p style="font-size: 13px; color: #666; margin-bottom: 8px;">${point.description || '暂无描述'}</p>
        <p style="font-size: 12px; color: #999;">📍 ${point.city} · ${point.province}</p>
        ${point.photos?.length > 0 ? `
          <div style="margin-top: 8px;">
            <span style="font-size: 12px; color: #999;">📷 ${point.photos.length} 张照片</span>
          </div>
        ` : ''}
      </div>
    `;

    const infoWindow = new AMap.InfoWindow({
      content: infoContent,
      offset: new AMap.Pixel(0, -16),
    });

    infoWindow.open(map, marker.getPosition());
  };

  const handleStyleChange = (style: 'normal' | 'satellite' | 'glass') => {
    setMapStyle(style);
    if (mapInstance) {
      mapInstance.setMapStyle(
        style === 'satellite' ? 'amap://styles/dark' : 
        style === 'glass' ? 'amap://styles/glass' : 'amap://styles/normal'
      );
    }
  };

  return (
    <div className="glass p-6">
      {/* 地图样式切换 */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => handleStyleChange('normal')}
          className={`px-4 py-2 rounded-lg text-sm ${mapStyle === 'normal' ? 'bg-rose-500 text-white' : 'bg-white/50'}`}
        >
          普通
        </button>
        <button
          onClick={() => handleStyleChange('satellite')}
          className={`px-4 py-2 rounded-lg text-sm ${mapStyle === 'satellite' ? 'bg-rose-500 text-white' : 'bg-white/50'}`}
        >
          卫星
        </button>
        <button
          onClick={() => handleStyleChange('glass')}
          className={`px-4 py-2 rounded-lg text-sm ${mapStyle === 'glass' ? 'bg-rose-500 text-white' : 'bg-white/50'}`}
        >
          玻璃
        </button>
      </div>

      {/* 地图容器 */}
      <div
        ref={mapRef}
        className="w-full h-[500px] rounded-lg overflow-hidden relative"
      >
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/50">
            <div className="text-rose-500">地图加载中...</div>
          </div>
        )}
      </div>

      {/* 选中点位详情 */}
      {selectedPoint && (
        <div className="mt-4 p-4 bg-white/30 rounded-lg">
          <h3 className="text-lg font-bold text-rose-600">{selectedPoint.name}</h3>
          <p className="text-gray-600 mt-1">{selectedPoint.description}</p>
          <div className="flex gap-2 mt-3">
            <span className="text-sm bg-rose-100 text-rose-600 px-2 py-1 rounded">
              {selectedPoint.city}
            </span>
            <span className="text-sm bg-pink-100 text-pink-600 px-2 py-1 rounded">
              {selectedPoint.province}
            </span>
          </div>
          {selectedPoint.photos?.length > 0 && (
            <div className="flex gap-2 mt-3 overflow-x-auto">
              {selectedPoint.photos.map((photo, i) => (
                <img
                  key={i}
                  src={photo}
                  alt=""
                  className="w-16 h-16 object-cover rounded-lg"
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
