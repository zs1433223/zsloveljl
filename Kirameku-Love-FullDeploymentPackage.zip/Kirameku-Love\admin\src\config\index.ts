module.exports = {
  // 项目配置
  projectName: 'Kirameku-Love',
  version: '1.0.0',
  author: 'Xinghongia',
  license: 'MIT',

  // 路由配置
  routes: {
    home: '/',
    dashboard: '/dashboard',
    records: '/records',
    recordDetail: '/records/:id',
    relationship: '/relationship',
    map: '/map',
    milestones: '/milestones',
    login: '/login',
    admin: '/admin',
    adminDashboard: '/admin/dashboard',
    adminUsers: '/admin/users',
    adminRecords: '/admin/records',
    adminMapPoints: '/admin/map-points',
    adminMilestones: '/admin/milestones',
  },

  // API 接口配置
  api: {
    baseUrl: 'http://localhost:8000/api',
    auth: {
      login: '/auth/login',
      logout: '/auth/logout',
      refreshToken: '/auth/refresh',
    },
    relationship: {
      get: '/relationship',
      update: '/relationship',
    },
    records: {
      list: '/records',
      detail: '/records/:id',
      create: '/records',
      update: '/records/:id',
      delete: '/records/:id',
      view: '/records/:id/view',
      comment: '/records/:id/comments',
    },
    mapPoints: {
      list: '/map-points',
      detail: '/map-points/:id',
      create: '/map-points',
      update: '/map-points/:id',
      delete: '/map-points/:id',
    },
    milestones: {
      list: '/milestones',
      detail: '/milestones/:id',
      create: '/milestones',
      update: '/milestones/:id',
      delete: '/milestones/:id',
    },
    users: {
      list: '/users',
      detail: '/users/:id',
      create: '/users',
      update: '/users/:id',
      delete: '/users/:id',
    },
    media: {
      upload: '/media/upload',
      delete: '/media/delete',
    },
  },

  // 常量配置
  constants: {
    // 页面大小
    PAGE_SIZE: 10,
    MAX_PAGE_SIZE: 100,

    // 时间格式
    DATE_FORMAT: 'YYYY-MM-DD',
    DATETIME_FORMAT: 'YYYY-MM-DD HH:mm:ss',

    // 状态码
    STATUS_CODE: {
      SUCCESS: 200,
      CREATED: 201,
      BAD_REQUEST: 400,
      UNAUTHORIZED: 401,
      FORBIDDEN: 403,
      NOT_FOUND: 404,
      SERVER_ERROR: 500,
    },

    // 角色
    ROLES: {
      ADMIN: 'admin',
      USER: 'user',
    },

    // 点位类型
    POINT_TYPES: {
      DATE: 'date',
      TRAVEL: 'travel',
      ANNIVERSARY: 'anniversary',
    },

    // 里程碑类型
    MILESTONE_TYPES: {
      ACHIEVEMENT: 'achievement',
      LOCATION: 'location',
      SPECIAL: 'special',
    },

    // 记录状态
    RECORD_STATUS: {
      DRAFT: 'draft',
      PUBLISHED: 'published',
      PRIVATE: 'private',
    },

    // 默认头像
    DEFAULT_AVATARS: [
      'https://picsum.photos/id/1/200/200',
      'https://picsum.photos/id/2/200/200',
      'https://picsum.photos/id/3/200/200',
      'https://picsum.photos/id/4/200/200',
      'https://picsum.photos/id/5/200/200',
    ],
  },
};
