"""
地图点位模型
"""
from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import datetime, timezone


class MapPoint(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100)
    description: str = Field(default="")
    longitude: float
    latitude: float
    city: str = Field(default="", max_length=50)
    province: str = Field(default="", max_length=50)
    country: str = Field(default="China", max_length=50)
    point_type: str = Field(default="location", max_length=50)  # location, achievement, special
    cover_image: str = Field(default="", max_length=500)
    photos: str = Field(default="[]")  # JSON array of image URLs
    videos: str = Field(default="[]")  # JSON array of video URLs
    sort_order: int = Field(default=0)
    status: str = Field(default="published", max_length=20)  # published, draft
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
