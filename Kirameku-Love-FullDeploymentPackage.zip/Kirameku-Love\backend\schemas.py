from typing import Optional
from pydantic import BaseModel
from datetime import datetime


class UserBase(BaseModel):
    username: str
    email: str
    nickname: Optional[str] = None
    avatar_url: Optional[str] = None
    role: str = "user"


class UserCreate(UserBase):
    password: str


class UserUpdate(UserBase):
    password: Optional[str] = None


class UserInDB(UserBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class UserResponse(UserBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    username: Optional[str] = None


class LoginRequest(BaseModel):
    username: str
    password: str


class RelationshipBase(BaseModel):
    partner1_name: str
    partner1_avatar: Optional[str] = None
    partner1_birthday: Optional[str] = None
    partner2_name: str
    partner2_avatar: Optional[str] = None
    partner2_birthday: Optional[str] = None
    start_date: str


class RelationshipCreate(RelationshipBase):
    pass


class RelationshipUpdate(RelationshipBase):
    pass


class RelationshipInDB(RelationshipBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class RelationshipResponse(RelationshipBase):
    id: int
    together_days: int
    birthday_countdown: dict
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class RecordBase(BaseModel):
    title: str
    content: str
    record_date: str
    status: str = "published"
    views: int = 0
    likes: int = 0


class RecordCreate(RecordBase):
    pass


class RecordUpdate(RecordBase):
    pass


class RecordInDB(RecordBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class LoveRecordBase(BaseModel):
    title: str
    content: str = ""
    record_date: str
    is_private: bool = False
    status: str = "published"


class LoveRecordCreate(LoveRecordBase):
    pass


class LoveRecordUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    record_date: Optional[str] = None
    is_private: Optional[bool] = None
    status: Optional[str] = None


class LoveRecordResponse(LoveRecordBase):
    id: int
    views: int
    likes: int
    media: List[RecordMediaResponse] = []
    comments: List[CommentResponse] = []
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class LoveRecordListResponse(BaseModel):
    total: int
    items: List[LoveRecordResponse]


class MapPointBase(BaseModel):
    name: str
    city: str
    province: str
    country: str = "China"
    longitude: float
    latitude: float
    point_type: str
    description: Optional[str] = None
    cover_image: Optional[str] = None
    photos: list[str] = []
    videos: list[str] = []
    sort_order: int = 0
    status: str = "published"


class MapPointCreate(MapPointBase):
    pass


class MapPointUpdate(MapPointBase):
    # 所有字段可选用于部分更新
    name: Optional[str] = None
    city: Optional[str] = None
    province: Optional[str] = None
    country: Optional[str] = None
    longitude: Optional[float] = None
    latitude: Optional[float] = None
    point_type: Optional[str] = None
    description: Optional[str] = None
    cover_image: Optional[str] = None
    photos: Optional[list[str]] = None
    videos: Optional[list[str]] = None
    sort_order: Optional[int] = None
    status: Optional[str] = None


class MapPointInDB(MapPointBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class MilestoneBase(BaseModel):
    title: str
    description: str
    milestone_type: str
    sort_order: int = 0
    is_completed: bool = False
    achieved_date: Optional[str] = None
    parent_id: Optional[int] = None


class MilestoneCreate(MilestoneBase):
    pass


class MilestoneUpdate(MilestoneBase):
    title: Optional[str] = None
    description: Optional[str] = None
    milestone_type: Optional[str] = None
    sort_order: Optional[int] = None
    is_completed: Optional[bool] = None
    achieved_date: Optional[str] = None
    parent_id: Optional[int] = None


class MilestoneInDB(MilestoneBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class MilestoneResponse(MilestoneBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class MapPointResponse(MapPointBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class MediaBase(BaseModel):
    original_filename: str
    file_url: str
    file_size: int
    file_type: str


class MediaCreate(MediaBase):
    pass


class MediaInDB(MediaBase):
    id: int
    user_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class RecordMediaBase(BaseModel):
    media_type: str
    media_url: str
    caption: str = ""
    sort_order: int = 0


class RecordMediaCreate(RecordMediaBase):
    record_id: int


class RecordMediaResponse(RecordMediaBase):
    id: int
    record_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class CommentBase(BaseModel):
    content: str
    record_id: int


class CommentCreate(CommentBase):
    pass


class CommentUpdate(CommentBase):
    pass


class CommentInDB(CommentBase):
    id: int
    user_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class CommentBase(BaseModel):
    content: str
    record_id: int
    nickname: str = ""
    avatar: str = ""
    parent_id: Optional[int] = None


class CommentCreate(CommentBase):
    pass


class CommentUpdate(CommentBase):
    pass


class CommentResponse(CommentBase):
    id: int
    record_id: int
    ip: str = ""
    status: str = "published"
    likes: int = 0
    created_at: datetime

    class Config:
        from_attributes = True


class Pagination(BaseModel):
    page: int = 1
    per_page: int = 10
    total: int = 0
    items: list

    class Config:
        from_attributes = True


class ApiResponse(BaseModel):
    code: int = 200
    message: str = "success"
    data: Optional[dict] = None

    class Config:
        from_attributes = True


class PaginatedResponse(ApiResponse):
    data: Pagination


class ErrorResponse(ApiResponse):
    code: int = 400
    message: str = "error"
    error: str = ""

    class Config:
        from_attributes = True


class WechatAvatarRequest(BaseModel):
    wechat_id: str


class WechatAvatarResponse(BaseModel):
    wechat_id: str
    avatar_url: str
    nickname: str = ""
