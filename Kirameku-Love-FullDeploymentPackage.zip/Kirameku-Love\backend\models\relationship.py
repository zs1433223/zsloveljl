"""
情侣关系模型
"""
from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import date, datetime


class Relationship(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    partner1_name: str = Field(max_length=50)
    partner1_avatar: str = Field(default="", max_length=500)
    partner1_birthday: Optional[date] = None
    partner2_name: str = Field(max_length=50)
    partner2_avatar: str = Field(default="", max_length=500)
    partner2_birthday: Optional[date] = None
    start_date: date
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)

    @property
    def together_days(self) -> int:
        """计算在一起天数"""
        from datetime import date as _date
        return (_date.today() - self.start_date).days + 1

    @property
    def birthday_countdown(self) -> dict:
        """计算双方生日倒计时"""
        from datetime import date as _date
        today = _date.today()
        countdown = {"partner1": None, "partner2": None}

        if self.partner1_birthday:
            next_bday = _date(today.year, self.partner1_birthday.month, self.partner1_birthday.day)
            if next_bday < today:
                next_bday = _date(today.year + 1, self.partner1_birthday.month, self.partner1_birthday.day)
            countdown["partner1"] = (next_bday - today).days

        if self.partner2_birthday:
            next_bday = _date(today.year, self.partner2_birthday.month, self.partner2_birthday.day)
            if next_bday < today:
                next_bday = _date(today.year + 1, self.partner2_birthday.month, self.partner2_birthday.day)
            countdown["partner2"] = (next_bday - today).days

        return countdown
