"""
认证路由 - 用户登录/注册
"""
from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlmodel import Session, select
from typing import Optional
from datetime import timedelta
import hashlib
import bcrypt
import os
from jose import jwt

from config import settings
from database import get_db
from models.user import User
from schemas import UserResponse

router = APIRouter()

SECRET_KEY = settings.SECRET_KEY
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_HOURS = 24


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))


def create_access_token(sub: str) -> str:
    payload = {"sub": sub, "exp": (os.path.getmtime(os.devnull) + timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS).total_seconds())}
    import time
    payload = {"sub": sub, "exp": time.time() + timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS).total_seconds()}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


@router.post("/register")
def register(
    data: dict,
    db: Session = Depends(get_db),
):
    """用户注册"""
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        raise HTTPException(status_code=400, detail="用户名和密码不能为空")

    # 检查是否已存在
    existing = db.exec(select(User).where(User.username == username)).first()
    if existing:
        raise HTTPException(status_code=400, detail="用户名已存在")

    user = User(
        username=username,
        hashed_password=hash_password(password),
        nickname=data.get("nickname", username),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    return {"message": "注册成功", "user": UserResponse.model_validate(user)}


@router.post("/login")
def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db),
):
    """用户登录"""
    user = db.exec(select(User).where(User.username == form_data.username)).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="用户名或密码错误")

    token = create_access_token(user.username)
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": UserResponse.model_validate(user),
    }


@router.get("/me")
def get_current_user(
    token: str,
    db: Session = Depends(get_db),
):
    """获取当前用户信息"""
    try:
        import time
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if not username:
            raise Exception("无效的 token")
    except Exception:
        raise HTTPException(status_code=401, detail="无效的认证令牌")

    user = db.exec(select(User).where(User.username == username)).first()
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")

    return UserResponse.model_validate(user)
