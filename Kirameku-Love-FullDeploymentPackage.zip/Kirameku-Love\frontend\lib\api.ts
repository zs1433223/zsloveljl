/**
 * API 工具函数 - 恋爱记录网站前端
 */

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || '';

async function request<T>(
  url: string,
  options: RequestInit = {}
): Promise<T> {
  const res = await fetch(`${API_BASE}${url}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    cache: 'no-store',
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.detail || res.statusText);
  }

  return res.json();
}

// ===== 关系 API =====
export function getRelationship() {
  return request<{
    partner1_name: string;
    partner1_avatar: string;
    partner1_birthday?: string;
    partner2_name: string;
    partner2_avatar: string;
    partner2_birthday?: string;
    start_date: string;
    together_days: number;
    birthday_countdown: { partner1: number | null; partner2: number | null };
  }>('/api/relationships/');
}

// ===== 恋爱记录 API =====
export interface LoveRecord {
  id: number;
  title: string;
  content: string;
  record_date: string;
  is_private: boolean;
  status: string;
  views: number;
  likes: number;
  media: Array<{
    id: number;
    media_type: string;
    media_url: string;
    caption: string;
  }>;
  comments: Array<{
    id: number;
    nickname: string;
    avatar: string;
    content: string;
    created_at: string;
  }>;
}

export function getLoveRecords(params?: {
  page?: number;
  per_page?: number;
  status?: string;
  start_date?: string;
  end_date?: string;
}) {
  const query = new URLSearchParams();
  if (params?.page) query.set('page', String(params.page));
  if (params?.per_page) query.set('per_page', String(params.per_page));
  if (params?.status) query.set('status', params.status);
  if (params?.start_date) query.set('start_date', params.start_date);
  if (params?.end_date) query.set('end_date', params.end_date);

  const qs = query.toString();
  return request<{ total: number; items: LoveRecord[] }>(
    `/api/love-records/${qs ? `?${qs}` : ''}`
  );
}

export function getLoveRecord(id: number) {
  return request<LoveRecord>(`/api/love-records/${id}`);
}

export function createLoveRecord(data: Partial<LoveRecord>) {
  return request<LoveRecord>('/api/love-records/', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export function updateLoveRecord(id: number, data: Partial<LoveRecord>) {
  return request<LoveRecord>(`/api/love-records/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export function deleteLoveRecord(id: number) {
  return request(`/api/love-records/${id}`, { method: 'DELETE' });
}

export function viewLoveRecord(id: number) {
  return request(`/api/love-records/${id}/view`, { method: 'POST' });
}

export function addComment(recordId: number, data: {
  nickname: string;
  content: string;
  avatar?: string;
}) {
  return request(`/api/love-records/${recordId}/comments`, {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

// ===== 媒体上传 API =====
export function uploadMedia(recordId: number, files: File[]) {
  const formData = new FormData();
  formData.append('record_id', String(recordId));
  files.forEach((file) => {
    formData.append('files', file);
  });

  return fetch(`${API_BASE}/api/media/upload`, {
    method: 'POST',
    body: formData,
  }).then((res) => res.json());
}

// ===== 地图 API =====
export interface MapPoint {
  id: number;
  name: string;
  description: string;
  longitude: number;
  latitude: number;
  city: string;
  province: string;
  country: string;
  point_type: string;
  cover_image: string;
  photos: string[];
  videos: string[];
}

export function getMapPoints(params?: {
  city?: string;
  province?: string;
  point_type?: string;
}) {
  const query = new URLSearchParams();
  if (params?.city) query.set('city', params.city);
  if (params?.province) query.set('province', params.province);
  if (params?.point_type) query.set('point_type', params.point_type);

  const qs = query.toString();
  return request<MapPoint[]>(`/api/map-points/${qs ? `?${qs}` : ''}`);
}

export function getMapPoint(id: number) {
  return request<MapPoint>(`/api/map-points/${id}`);
}

export function createMapPoint(data: Partial<MapPoint>) {
  return request<MapPoint>('/api/map-points/', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export function updateMapPoint(id: number, data: Partial<MapPoint>) {
  return request<MapPoint>(`/api/map-points/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export function deleteMapPoint(id: number) {
  return request(`/api/map-points/${id}`, { method: 'DELETE' });
}

// ===== 里程碑 API =====
export interface Milestone {
  id: number;
  title: string;
  description: string;
  milestone_type: string;
  achieved_date?: string;
  is_completed: boolean;
  parent_id?: number;
  sort_order: number;
  children?: Milestone[];
}

export function getMilestoneTree() {
  return request<{ tree: Milestone[]; stats: {
    total: number;
    completed: number;
    pending: number;
    completion_rate: number;
  } }>('/api/milestones/tree');
}

export function getMilestones() {
  return request<Milestone[]>('/api/milestones/');
}

export function createMilestone(data: Partial<Milestone>) {
  return request<Milestone>('/api/milestones/', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export function updateMilestone(id: number, data: Partial<Milestone>) {
  return request<Milestone>(`/api/milestones/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export function deleteMilestone(id: number) {
  return request(`/api/milestones/${id}`, { method: 'DELETE' });
}

// ===== 微信头像 API =====
export function getWechatAvatar(wechatId: string) {
  return request<{ wechat_id: string; avatar_url: string; nickname: string }>(
    '/api/wechat/avatar',
    {
      method: 'POST',
      body: JSON.stringify({ wechat_id: wechatId }),
    }
  );
}
