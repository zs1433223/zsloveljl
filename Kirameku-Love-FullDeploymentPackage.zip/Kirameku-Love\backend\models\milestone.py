"""
里程碑模型（完成事项树）
"""
from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import date, datetime


class Milestone(SQLModel, table=True):
    __tablename__ = "milestones"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str = Field(max_length=100)
    description: str = Field(default="")
    milestone_type: str = Field(default="achievement", max_length=50)  # achievement, location, special
    achieved_date: Optional[date] = None
    is_completed: bool = Field(default=False)
    parent_id: Optional[int] = Field(default=None, foreign_key="milestones.id")
    sort_order: int = Field(default=0)
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
