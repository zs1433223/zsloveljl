"""
Schemas - 请求/响应数据模型
"""
from pydantic import BaseModel
from typing import Optional, List
from datetime import date, datetime


# ===== 用户相关 =====
class UserBase(BaseModel):
    username: str
    nickname: str = ""
    avatar: str = ""
    wechat_id: str = ""
    email: str = ""
    role: str = "user"
    bio: str = ""


class UserCreate(UserBase):
    password: str


class UserUpdate(UserBase):
    password: Optional[str] = None


class UserResponse(UserBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ===== 关系相关 =====
class RelationshipBase(BaseModel):
    partner1_name: str
    partner1_avatar: str = ""
    partner1_birthday: Optional[date] = None
    partner2_name: str
    partner2_avatar: str = ""
    partner2_birthday: Optional[date] = None
    start_date: date


class RelationshipCreate(RelationshipBase):
    pass


class RelationshipUpdate(BaseModel):
    partner1_name: Optional[str] = None
    partner1_avatar: Optional[str] = None
    partner1_birthday: Optional[date] = None
    partner2_name: Optional[str] = None
    partner2_avatar: Optional[str] = None
    partner2_birthday: Optional[date] = None
    start_date: Optional[date] = None


class RelationshipResponse(RelationshipBase):
    id: int
    together_days: int
    birthday_countdown: dict
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ===== 恋爱记录相关 =====
class LoveRecordBase(BaseModel):
    title: str
    content: str = ""
    record_date: date
    is_private: bool = False
    status: str = "published"


class LoveRecordCreate(LoveRecordBase):
    pass


class LoveRecordUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    record_date: Optional[date] = None
    is_private: Optional[bool] = None
    status: Optional[str] = None


class LoveRecordResponse(LoveRecordBase):
    id: int
    views: int
    likes: int
    media: List["RecordMediaResponse"] = []
    comments: List["CommentResponse"] = []
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class LoveRecordListResponse(BaseModel):
    total: int
    items: List[LoveRecordResponse]


# ===== 媒体相关 =====
class RecordMediaBase(BaseModel):
    media_type: str  # image, video
    media_url: str
    caption: str = ""
    sort_order: int = 0


class RecordMediaCreate(RecordMediaBase):
    record_id: int


class RecordMediaResponse(RecordMediaBase):
    id: int
    record_id: int
    created_at: datetime

    class Config:
        from_attributes = True


# ===== 评论相关 =====
class CommentBase(BaseModel):
    nickname: str
    avatar: str = ""
    content: str
    parent_id: Optional[int] = None


class CommentCreate(CommentBase):
    record_id: int


class CommentResponse(CommentBase):
    id: int
    record_id: int
    ip: str
    status: str
    likes: int
    created_at: datetime

    class Config:
        from_attributes = True


# ===== 里程碑相关 =====
class MilestoneBase(BaseModel):
    title: str
    description: str = ""
    milestone_type: str = "achievement"
    achieved_date: Optional[date] = None
    is_completed: bool = False
    parent_id: Optional[int] = None
    sort_order: int = 0


class MilestoneCreate(MilestoneBase):
    pass


class MilestoneUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    milestone_type: Optional[str] = None
    achieved_date: Optional[date] = None
    is_completed: Optional[bool] = None
    parent_id: Optional[int] = None
    sort_order: Optional[int] = None


class MilestoneResponse(MilestoneBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ===== 地图点位相关 =====
class MapPointBase(BaseModel):
    name: str
    description: str = ""
    longitude: float
    latitude: float
    city: str = ""
    province: str = ""
    country: str = "China"
    point_type: str = "location"
    cover_image: str = ""
    photos: List[str] = []
    videos: List[str] = []
    sort_order: int = 0
    status: str = "published"


class MapPointCreate(MapPointBase):
    pass


class MapPointUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    longitude: Optional[float] = None
    latitude: Optional[float] = None
    city: Optional[str] = None
    province: Optional[str] = None
    country: Optional[str] = None
    point_type: Optional[str] = None
    cover_image: Optional[str] = None
    photos: Optional[List[str]] = None
    videos: Optional[List[str]] = None
    sort_order: Optional[int] = None
    status: Optional[str] = None


class MapPointResponse(MapPointBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ===== 微信相关 =====
class WechatAvatarRequest(BaseModel):
    wechat_id: str


class WechatAvatarResponse(BaseModel):
    wechat_id: str
    avatar_url: str
    nickname: str = ""
