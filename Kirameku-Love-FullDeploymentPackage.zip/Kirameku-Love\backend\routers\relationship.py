"""
关系路由
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session

from database import get_db
from services import relationship_service
from schemas import RelationshipCreate, RelationshipUpdate, RelationshipResponse

router = APIRouter()


@router.get("/", response_model=RelationshipResponse)
def get_relationship(db: Session = Depends(get_db)):
    """获取情侣关系信息（含在一起天数和生日倒计时）"""
    rel = relationship_service.get_relationship(db)
    if not rel:
        raise HTTPException(status_code=404, detail="关系未初始化")
    return rel


@router.post("/", response_model=RelationshipResponse)
def init_relationship(data: RelationshipCreate, db: Session = Depends(get_db)):
    """初始化情侣关系（首次设置）"""
    try:
        return relationship_service.init_relation(db, data)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/{rel_id}", response_model=RelationshipResponse)
def update_relationship(rel_id: int, data: RelationshipUpdate, db: Session = Depends(get_db)):
    """更新情侣关系"""
    rel = relationship_service.update_relationship(db, rel_id, data)
    if not rel:
        raise HTTPException(status_code=404, detail="关系不存在")
    return rel
