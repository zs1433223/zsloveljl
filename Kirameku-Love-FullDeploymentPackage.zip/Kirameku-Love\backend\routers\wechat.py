"""
微信路由 - 通过微信号获取头像
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session

from database import get_db
from services.wechat_service import fetch_avatar_by_wechat_id, get_wechat_user_info
from schemas import WechatAvatarRequest, WechatAvatarResponse

router = APIRouter()


@router.post("/avatar", response_model=WechatAvatarResponse)
async def get_avatar_by_wechat(data: WechatAvatarRequest, db: Session = Depends(get_db)):
    """
    通过微信号获取头像 URL
    需要配置 WECHAT_APPID 和 WECHAT_SECRET
    """
    try:
        result = await fetch_avatar_by_wechat_id(data.wechat_id)
        return WechatAvatarResponse(
            wechat_id=data.wechat_id,
            avatar_url=result.get("avatar_url", ""),
            nickname=result.get("nickname", ""),
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/userinfo/{unionid}", response_model=WechatAvatarResponse)
async def get_wechat_userinfo(unionid: str, db: Session = Depends(get_db)):
    """
    通过 unionid 获取微信用户信息（包括头像）
    """
    try:
        result = await get_wechat_user_info(unionid)
        return WechatAvatarResponse(
            wechat_id=unionid,
            avatar_url=result.get("avatar_url", ""),
            nickname=result.get("nickname", ""),
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
