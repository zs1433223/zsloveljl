<template>
  <div class="milestones-container">
    <el-card shadow="hover">
      <template #header>
        <div class="card-header">
          <span>🏆 里程碑</span>
        </div>
      </template>

      <!-- 操作栏 -->
      <div class="actions">
        <el-button type="primary" @click="handleCreate">新建里程碑</el-button>
        <el-button @click="refresh">刷新</el-button>
      </div>

      <!-- 搜索栏 -->
      <div class="search-bar">
        <el-input
          v-model="keyword"
          placeholder="搜索标题或描述"
          prefix-icon="Search"
          style="width: 300px"
          clearable
          @clear="fetchMilestones"
        />
        <el-select v-model="milestoneType" placeholder="全部类型" style="width: 120px" @change="fetchMilestones">
          <el-option label="全部" value="" />
          <el-option label="成就" value="achievement" />
          <el-option label="地点" value="location" />
          <el-option label="特别" value="special" />
        </el-select>
      </div>

      <!-- 表格 -->
      <el-table
        :data="milestones"
        style="width: 100%"
        stripe
        border
        v-loading="loading"
      >
        <el-table-column prop="title" label="标题" min-width="200">
          <template #default="scope">
            <el-link type="primary" @click="handleView(scope.row)">{{ scope.row.title }}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="description" label="描述" min-width="200" />
        <el-table-column prop="milestone_type" label="类型" min-width="100">
          <template #default="scope">
            <el-tag
              :type="scope.row.milestone_type === 'achievement' ? 'primary' : scope.row.milestone_type === 'location' ? 'success' : 'warning'"
              effect="plain"
            >
              {{ scope.row.milestone_type === 'achievement' ? '成就' : scope.row.milestone_type === 'location' ? '地点' : '特别' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="sort_order" label="排序" min-width="100" />
        <el-table-column prop="is_completed" label="状态" min-width="100">
          <template #default="scope">
            <el-tag
              :type="scope.row.is_completed ? 'success' : 'info'"
              effect="plain"
            >
              {{ scope.row.is_completed ? '已完成' : '未完成' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="achieved_date" label="完成日期" min-width="120">
          <template #default="scope">
            {{ formatDate(scope.row.achieved_date) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" min-width="180">
          <template #default="scope">
            <el-button type="primary" size="small" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          :current-page="currentPage"
          :page-sizes="[10, 20, 50, 100]"
          :page-size="pageSize"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useRouter } from 'vue-router'
import { getMilestones, deleteMilestone } from '@/utils/api'

const router = useRouter()

// 表单数据
const keyword = ref('')
const milestoneType = ref('')
const milestones = ref([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(10)
const loading = ref(false)

// 获取里程碑列表
const fetchMilestones = async () => {
  loading.value = true
  try {
    const res = await getMilestones({
      keyword: keyword.value,
      milestone_type: milestoneType.value,
      page: currentPage.value,
      per_page: pageSize.value
    })
    milestones.value = res
    total.value = res.length
  } catch (e) {
    ElMessage.error('获取里程碑列表失败')
  } finally {
    loading.value = false
  }
}

// 新建里程碑
const handleCreate = () => {
  router.push('/milestones/create')
}

// 查看里程碑
const handleView = (row: any) => {
  router.push(`/milestones/${row.id}`)
}

// 编辑里程碑
const handleEdit = (row: any) => {
  router.push(`/milestones/${row.id}/edit`)
}

// 删除里程碑
const handleDelete = (row: any) => {
  ElMessageBox.confirm(
    `确定要删除里程碑 ${row.title} 吗？`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  ).then(async () => {
    try {
      await deleteMilestone(row.id)
      ElMessage.success('删除成功')
      fetchMilestones()
    } catch (e) {
      ElMessage.error('删除失败')
    }
  })
}

// 刷新
const refresh = () => {
  fetchMilestones()
}

// 分页事件
const handleSizeChange = (val: number) => {
  pageSize.value = val
  fetchMilestones()
}

const handleCurrentChange = (val: number) => {
  currentPage.value = val
  fetchMilestones()
}

// 格式化日期
const formatDate = (dateStr: string) => {
  if (!dateStr) return ''
  const date = new Date(dateStr)
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-`
    + `${String(date.getDate()).padStart(2, '0')}`
}

onMounted(() => {
  fetchMilestones()
})
</script>

<style scoped>
.milestones-container {
  padding: 20px;
}

.actions {
  margin-bottom: 20px;
}

.search-bar {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  align-items: center;
}

.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>
