import RelationshipCard from '@/components/RelationshipCard';
import LoveRecordList from '@/components/LoveRecordList';
import MapSection from '@/components/MapSection';
import MilestoneTree from '@/components/MilestoneTree';

export const revalidate = 60; // ISR 缓存 60 秒

export default function Home() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-8">
      {/* 首页双头像 + 在一起天数 + 生日倒计时 */}
      <section id="relationship">
        <RelationshipCard />
      </section>

      {/* 恋爱记录列表 */}
      <section id="records" className="mt-16">
        <h2 className="text-3xl font-bold text-rose-600 mb-6 text-center">
          💕 我们的恋爱记录
        </h2>
        <LoveRecordList />
      </section>

      {/* 高德地图 - 城市点位 */}
      <section id="map" className="mt-16">
        <h2 className="text-3xl font-bold text-rose-600 mb-6 text-center">
          🗺️ 我们的足迹
        </h2>
        <MapSection />
      </section>

      {/* 完成事项树 - 里程碑 */}
      <section id="milestones" className="mt-16">
        <h2 className="text-3xl font-bold text-rose-600 mb-6 text-center">
          🎯 我们的里程碑
        </h2>
        <MilestoneTree />
      </section>
    </main>
  );
}
