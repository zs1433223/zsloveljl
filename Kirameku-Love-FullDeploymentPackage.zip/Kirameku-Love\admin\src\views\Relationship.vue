<template>
  <div class="relationship-container">
    <el-card shadow="hover">
      <template #header>
        <div class="card-header">
          <span>❤️ 关系管理</span>
        </div>
      </template>

      <!-- 表单 -->
      <el-form
        :model="form"
        :rules="rules"
        ref="formRef"
        label-width="120px"
        class="form"
      >
        <el-form-item label="伴侣姓名" prop="partner1_name">
          <el-input v-model="form.partner1_name" placeholder="请输入伴侣姓名" />
        </el-form-item>
        <el-form-item label="伴侣头像" prop="partner1_avatar">
          <el-upload
            action="/api/media/upload"
            :show-file-list="false"
            :on-success="handlePartner1AvatarSuccess"
            :before-upload="beforeUpload"
            accept="image/*"
          >
            <el-avatar
              :size="80"
              :src="form.partner1_avatar || undefined"
              :alt="form.partner1_name"
            />
          </el-upload>
        </el-form-item>
        <el-form-item label="伴侣生日" prop="partner1_birthday">
          <el-date-picker
            v-model="form.partner1_birthday"
            type="date"
            placeholder="请选择生日"
            value-format="YYYY-MM-DD"
          />
        </el-form-item>
        <el-form-item label="我的姓名" prop="partner2_name">
          <el-input v-model="form.partner2_name" placeholder="请输入我的姓名" />
        </el-form-item>
        <el-form-item label="我的头像" prop="partner2_avatar">
          <el-upload
            action="/api/media/upload"
            :show-file-list="false"
            :on-success="handlePartner2AvatarSuccess"
            :before-upload="beforeUpload"
            accept="image/*"
          >
            <el-avatar
              :size="80"
              :src="form.partner2_avatar || undefined"
              :alt="form.partner2_name"
            />
          </el-upload>
        </el-form-item>
        <el-form-item label="我的生日" prop="partner2_birthday">
          <el-date-picker
            v-model="form.partner2_birthday"
            type="date"
            placeholder="请选择生日"
            value-format="YYYY-MM-DD"
          />
        </el-form-item>
        <el-form-item label="开始日期" prop="start_date">
          <el-date-picker
            v-model="form.start_date"
            type="date"
            placeholder="请选择开始日期"
            value-format="YYYY-MM-DD"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSubmit">保存</el-button>
          <el-button @click="resetForm">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { getRelationship, updateRelationship } from '@/utils/api'

// 表单数据
const formRef = ref()
const form = ref({
  partner1_name: '',
  partner1_avatar: '',
  partner1_birthday: '',
  partner2_name: '',
  partner2_avatar: '',
  partner2_birthday: '',
  start_date: '',
})

// 表单规则
const rules = {
  partner1_name: [{ required: true, message: '请输入伴侣姓名', trigger: 'blur' }],
  partner2_name: [{ required: true, message: '请输入我的姓名', trigger: 'blur' }],
  start_date: [{ required: true, message: '请选择开始日期', trigger: 'blur' }],
}

// 上传前校验
const beforeUpload = (rawFile: File) => {
  if (rawFile.size > 5 * 1024 * 1024) {
    ElMessage.error('文件大小不能超过 5MB')
    return false
  }
  return true
}

// 上传成功回调
const handlePartner1AvatarSuccess = (res: any) => {
  form.value.partner1_avatar = res.url
}

const handlePartner2AvatarSuccess = (res: any) => {
  form.value.partner2_avatar = res.url
}

// 提交表单
const handleSubmit = async () => {
  await formRef.value.validate()

  try {
    await updateRelationship(form.value)
    ElMessage.success('保存成功')
  } catch (e) {
    ElMessage.error('保存失败')
  }
}

// 重置表单
const resetForm = () => {
  formRef.value.resetFields()
}

// 获取当前关系数据
const fetchRelationship = async () => {
  try {
    const res = await getRelationship()
    form.value = {
      partner1_name: res.partner1_name,
      partner1_avatar: res.partner1_avatar,
      partner1_birthday: res.partner1_birthday || '',
      partner2_name: res.partner2_name,
      partner2_avatar: res.partner2_avatar,
      partner2_birthday: res.partner2_birthday || '',
      start_date: res.start_date,
    }
  } catch (e) {
    ElMessage.error('获取关系数据失败')
  }
}

onMounted(() => {
  fetchRelationship()
})
</script>

<style scoped>
.relationship-container {
  padding: 20px;
}

.form {
  max-width: 600px;
}
</style>
