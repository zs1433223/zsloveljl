<template>
  <div class="milestone-form-container">
    <el-card shadow="hover">
      <template #header>
        <div class="card-header">
          <span>{{ isEdit ? '编辑里程碑' : '新建里程碑' }}</span>
        </div>
      </template>

      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-width="120px"
        label-position="right"
        style="width: 100%; max-width: 800px;"
      >
        <!-- 基本信息 -->
        <div class="form-section">
          <h4>基本信息</h4>
          
          <el-row :gutter="20">
            <el-col :span="24">
              <el-form-item label="标题" prop="title">
                <el-input v-model="form.title" placeholder="请输入里程碑标题" maxlength="100" />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="类型" prop="milestone_type">
                <el-select v-model="form.milestone_type" placeholder="请选择类型" style="width: 100%">
                  <el-option label="成就" value="achievement" />
                  <el-option label="地点" value="location" />
                  <el-option label="特别" value="special" />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="状态" prop="is_completed">
                <el-radio-group v-model="form.is_completed" style="width: 100%">
                  <el-radio :label="true">已完成</el-radio>
                  <el-radio :label="false">未完成</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>

          <el-form-item label="描述" prop="description">
            <el-input
              v-model="form.description"
              type="textarea"
              :rows="3"
              placeholder="请输入描述信息"
              maxlength="500"
              show-word-limit
            />
          </el-form-item>

          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="完成日期" prop="achieved_date">
                <el-date-picker
                  v-model="form.achieved_date"
                  type="date"
                  placeholder="选择日期"
                  value-format="YYYY-MM-DD"
                  style="width: 100%"
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="父级里程碑" prop="parent_id">
                <el-select v-model="form.parent_id" placeholder="可选：选择父级" style="width: 100%" clearable>
                  <el-option
                    v-for="m in parentOptions"
                    :key="m.id"
                    :label="m.title"
                    :value="m.id"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="排序" prop="sort_order">
                <el-input-number v-model="form.sort_order" :min="0" :controls="false" placeholder="排序值" />
              </el-form-item>
            </el-col>
          </el-row>
        </div>

        <!-- 操作按钮 -->
        <div class="form-actions">
          <el-button @click="handleCancel">取消</el-button>
          <el-button type="primary" @click="handleSubmit">保存</el-button>
        </div>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getMilestones, getMilestone, createMilestone, updateMilestone } from '@/utils/api'

const router = useRouter()
const route = useRoute()

const formRef = ref()
const isEdit = ref(false)
const milestoneId = ref<number | null>(null)
const parentOptions = ref<any[]>([])

const form = reactive({
  title: '',
  description: '',
  milestone_type: 'achievement',
  achieved_date: null as string | null,
  is_completed: false,
  parent_id: null as number | null,
  sort_order: 0,
})

const rules = reactive({
  title: [{ required: true, message: '请输入里程碑标题', trigger: 'blur' }],
  milestone_type: [{ required: true, message: '请选择类型', trigger: 'change' }],
})

// 加载父级选项
const loadParentOptions = async () => {
  try {
    const res = await getMilestones({ per_page: 100 })
    parentOptions.value = res.filter(m => !isEdit.value || m.id !== milestoneId.value)
  } catch (e) {
    ElMessage.warning('加载父级选项失败')
  }
}

// 加载编辑数据
const loadMilestone = async () => {
  const id = route.params.id
  if (id) {
    isEdit.value = true
    milestoneId.value = Number(id)
    try {
      const res = await getMilestone(milestoneId.value)
      form.title = res.title
      form.description = res.description
      form.milestone_type = res.milestone_type
      form.achieved_date = res.achieved_date
      form.is_completed = res.is_completed
      form.parent_id = res.parent_id
      form.sort_order = res.sort_order

      await loadParentOptions()
    } catch (e) {
      ElMessage.error('加载里程碑详情失败')
      router.push('/milestones')
    }
  } else {
    await loadParentOptions()
  }
}

// 提交表单
const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
  } catch (e) {
    return
  }

  const loading = ElMessage.loading({ message: '保存中...' })
  try {
    const submitData = {
      ...form,
      achieved_date: form.achieved_date || null,
    }

    if (isEdit.value && milestoneId.value) {
      await updateMilestone(milestoneId.value, submitData)
      ElMessage.success('更新成功')
    } else {
      await createMilestone(submitData)
      ElMessage.success('创建成功')
    }
    router.push('/milestones')
  } catch (e: any) {
    ElMessage.error(e.response?.data?.detail || '保存失败')
  } finally {
    loading.close()
  }
}

// 取消
const handleCancel = () => {
  router.push('/milestones')
}

// 监听路由变化
watch(() => route.params.id, (newId) => {
  if (newId) {
    loadMilestone()
  } else {
    // 重置表单
    Object.assign(form, {
      title: '',
      description: '',
      milestone_type: 'achievement',
      achieved_date: null,
      is_completed: false,
      parent_id: null,
      sort_order: 0,
    })
  }
}, { immediate: true })

onMounted(() => {
  if (route.params.id) {
    loadMilestone()
  } else {
    loadParentOptions()
  }
})
</script>

<style scoped>
.milestone-form-container {
  padding: 20px;
}

.form-section h4 {
  margin: 0 0 16px;
  padding-bottom: 8px;
  border-bottom: 1px solid #ebeef5;
  color: #303133;
  font-size: 16px;
  font-weight: 600;
}

.form-actions {
  margin-top: 30px;
  padding-top: 20px;
  border-top: 1px solid #ebeef5;
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}
</style>