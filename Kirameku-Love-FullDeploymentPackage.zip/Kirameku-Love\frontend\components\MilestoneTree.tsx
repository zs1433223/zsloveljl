/**
 * MilestoneTree 组件
 * 完成事项树 - 里程碑统计、树状/列表展示
 */
'use client';

import { useState, useEffect } from 'react';
import { getMilestoneTree, Milestone } from '@/lib/api';

export default function MilestoneTree() {
  const [tree, setTree] = useState<Milestone[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    completed: 0,
    pending: 0,
    completion_rate: 0,
  });
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'tree' | 'list'>('tree');

  useEffect(() => {
    getMilestoneTree()
      .then((res) => {
        setTree(res.tree);
        setStats(res.stats);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="glass p-6 animate-pulse">
        <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
        <div className="h-3 bg-gray-100 rounded w-full mb-2"></div>
        <div className="h-3 bg-gray-100 rounded w-3/4"></div>
      </div>
    );
  }

  return (
    <div className="glass p-6">
      {/* 统计卡片 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-gradient-to-br from-rose-50 to-pink-50 p-4 rounded-lg text-center">
          <div className="text-2xl font-bold text-rose-600">{stats.total}</div>
          <div className="text-sm text-gray-500">总里程碑</div>
        </div>
        <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-4 rounded-lg text-center">
          <div className="text-2xl font-bold text-green-600">{stats.completed}</div>
          <div className="text-sm text-gray-500">已完成</div>
        </div>
        <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-4 rounded-lg text-center">
          <div className="text-2xl font-bold text-blue-600">{stats.pending}</div>
          <div className="text-sm text-gray-500">待完成</div>
        </div>
        <div className="bg-gradient-to-br from-purple-50 to-violet-50 p-4 rounded-lg text-center">
          <div className="text-2xl font-bold text-purple-600">{stats.completion_rate}%</div>
          <div className="text-sm text-gray-500">完成率</div>
        </div>
      </div>

      {/* 进度条 */}
      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-500 mb-1">
          <span>完成进度</span>
          <span>{stats.completion_rate}%</span>
        </div>
        <div className="countdown-bar h-3">
          <div
            className="countdown-bar-fill"
            style={{ width: `${stats.completion_rate}%` }}
          />
        </div>
      </div>

      {/* 视图切换 */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setViewMode('tree')}
          className={`px-4 py-2 rounded-lg text-sm ${viewMode === 'tree' ? 'bg-rose-500 text-white' : 'bg-white/50'}`}
        >
          🌳 树状
        </button>
        <button
          onClick={() => setViewMode('list')}
          className={`px-4 py-2 rounded-lg text-sm ${viewMode === 'list' ? 'bg-rose-500 text-white' : 'bg-white/50'}`}
        >
          📋 列表
        </button>
      </div>

      {/* 树状视图 */}
      {viewMode === 'tree' ? (
        <div className="space-y-2">
          {tree.map((node) => (
            <MilestoneTreeNode key={node.id} node={node} level={0} />
          ))}
        </div>
      ) : (
        /* 列表视图 */
        <div className="space-y-2">
          {getAllMilestones(tree).map((item) => (
            <div
              key={item.id}
              className={`flex items-center gap-3 p-3 rounded-lg ${item.is_completed ? 'bg-green-50' : 'bg-gray-50'}`}
            >
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-xs ${item.is_completed ? 'bg-green-500' : 'bg-gray-300'}`}>
                {item.is_completed ? '✓' : '○'}
              </div>
              <div className="flex-1">
                <div className="font-medium">{item.title}</div>
                <div className="text-sm text-gray-500">{item.description}</div>
              </div>
              {item.achieved_date && (
                <div className="text-sm text-gray-400">
                  {new Date(item.achieved_date).toLocaleDateString('zh-CN')}
                </div>
              )}
              <div className={`text-xs px-2 py-1 rounded ${item.milestone_type === 'achievement' ? 'bg-rose-100 text-rose-600' : item.milestone_type === 'location' ? 'bg-blue-100 text-blue-600' : 'bg-purple-100 text-purple-600'}`}>
                {item.milestone_type === 'achievement' ? '成就' : item.milestone_type === 'location' ? '地点' : '特别'}
              </div>
            </div>
          ))}
        </div>
      )}

      {tree.length === 0 && (
        <div className="text-center py-8 text-gray-400">
          <p>还没有里程碑哦~</p>
          <p className="mt-2 text-sm">等待管理员添加第一个里程碑</p>
        </div>
      )}
    </div>
  );
}

// 递归渲染树节点
function MilestoneTreeNode({ node, level }: { node: Milestone; level: number }) {
  return (
    <div className="animate-fade-in">
      <div
        className={`flex items-center gap-3 p-3 rounded-lg transition-all ${node.is_completed ? 'bg-green-50 hover:bg-green-100' : 'bg-gray-50 hover:bg-gray-100'}`}
        style={{ marginLeft: `${level * 24}px` }}
      >
        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-xs flex-shrink-0 ${node.is_completed ? 'bg-green-500' : 'bg-gray-300'}`}>
          {node.is_completed ? '✓' : '○'}
        </div>
        <div className="flex-1">
          <div className="font-medium">{node.title}</div>
          <div className="text-sm text-gray-500">{node.description}</div>
          {node.achieved_date && (
            <div className="text-xs text-gray-400 mt-1">
              完成于 {new Date(node.achieved_date).toLocaleDateString('zh-CN')}
            </div>
          )}
        </div>
        <div className={`text-xs px-2 py-1 rounded ${node.milestone_type === 'achievement' ? 'bg-rose-100 text-rose-600' : node.milestone_type === 'location' ? 'bg-blue-100 text-blue-600' : 'bg-purple-100 text-purple-600'}`}>
          {node.milestone_type === 'achievement' ? '成就' : node.milestone_type === 'location' ? '地点' : '特别'}
        </div>
      </div>
      {node.children?.map((child) => (
        <MilestoneTreeNode key={child.id} node={child} level={level + 1} />
      ))}
    </div>
  );
}

// 递归展开所有节点为列表
function getAllMilestones(nodes: Milestone[]): Milestone[] {
  const result: Milestone[] = [];
  for (const node of nodes) {
    result.push(node);
    if (node.children) {
      result.push(...getAllMilestones(node.children));
    }
  }
  return result;
}
