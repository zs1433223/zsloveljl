"""
里程碑路由（完成事项树）
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from typing import List, Optional

from database import get_db
from models.milestone import Milestone
from schemas import MilestoneCreate, MilestoneUpdate, MilestoneResponse

router = APIRouter()


def build_tree(items: List[Milestone]) -> List[dict]:
    """将扁平列表构建为树状结构"""
    item_map = {}
    roots = []

    for item in items:
        node = {
            "id": item.id,
            "title": item.title,
            "description": item.description,
            "milestone_type": item.milestone_type,
            "achieved_date": item.achieved_date.isoformat() if item.achieved_date else None,
            "is_completed": item.is_completed,
            "parent_id": item.parent_id,
            "sort_order": item.sort_order,
            "created_at": item.created_at.isoformat(),
            "updated_at": item.updated_at.isoformat(),
            "children": [],
        }
        item_map[item.id] = node

    for node in item_map.values():
        if node["parent_id"] and node["parent_id"] in item_map:
            item_map[node["parent_id"]]["children"].append(node)
        else:
            roots.append(node)

    # 排序
    def sort_nodes(nodes):
        nodes.sort(key=lambda x: (x["sort_order"], x["title"]))
        for n in nodes:
            sort_nodes(n["children"])

    sort_nodes(roots)
    return roots


def milestone_to_dict(item: Milestone) -> dict:
    """将 Milestone 模型转换为字典，包含 parent_id"""
    return {
        "id": item.id,
        "title": item.title,
        "description": item.description,
        "milestone_type": item.milestone_type,
        "achieved_date": item.achieved_date.isoformat() if item.achieved_date else None,
        "is_completed": item.is_completed,
        "parent_id": item.parent_id,
        "sort_order": item.sort_order,
        "created_at": item.created_at.isoformat(),
        "updated_at": item.updated_at.isoformat(),
    }


@router.get("", response_model=List[MilestoneResponse])
def list_milestones(
    milestone_type: Optional[str] = None,
    is_completed: Optional[bool] = None,
    db: Session = Depends(get_db),
):
    """获取里程碑列表（扁平）"""
    query = select(Milestone)

    if milestone_type:
        query = query.where(Milestone.milestone_type == milestone_type)
    if is_completed is not None:
        query = query.where(Milestone.is_completed == is_completed)

    query = query.order_by(Milestone.sort_order, Milestone.id)
    items = db.exec(query).all()

    return [MilestoneResponse.model_validate(i) for i in items]


@router.get("/tree")
def get_milestone_tree(db: Session = Depends(get_db)):
    """获取里程碑树状结构"""
    items = db.exec(
        select(Milestone).order_by(Milestone.sort_order, Milestone.id)
    ).all()
    tree = build_tree(items)

    # 统计
    total = len(items)
    completed = sum(1 for i in items if i.is_completed)
    stats = {
        "total": total,
        "completed": completed,
        "pending": total - completed,
        "completion_rate": round(completed / total * 100, 1) if total > 0 else 0,
    }

    return {"tree": tree, "stats": stats}


@router.get("/{milestone_id}", response_model=MilestoneResponse)
def get_milestone(milestone_id: int, db: Session = Depends(get_db)):
    """获取单个里程碑"""
    item = db.get(Milestone, milestone_id)
    if not item:
        raise HTTPException(status_code=404, detail="里程碑不存在")
    return MilestoneResponse.model_validate(item)


@router.post("/", response_model=MilestoneResponse)
def create_milestone(data: MilestoneCreate, db: Session = Depends(get_db)):
    """创建里程碑（仅管理员）"""
    item = Milestone(**data.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return MilestoneResponse.model_validate(item)


@router.put("/{milestone_id}", response_model=MilestoneResponse)
def update_milestone(
    milestone_id: int, data: MilestoneUpdate, db: Session = Depends(get_db)
):
    """更新里程碑（仅管理员）"""
    item = db.get(Milestone, milestone_id)
    if not item:
        raise HTTPException(status_code=404, detail="里程碑不存在")

    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(item, key, value)

    db.add(item)
    db.commit()
    db.refresh(item)
    return MilestoneResponse.model_validate(item)


@router.delete("/{milestone_id}")
def delete_milestone(milestone_id: int, db: Session = Depends(get_db)):
    """删除里程碑（仅管理员）"""
    item = db.get(Milestone, milestone_id)
    if not item:
        raise HTTPException(status_code=404, detail="里程碑不存在")
    db.delete(item)
    db.commit()
    return {"message": "里程碑已删除"}
