"""
恋爱记录网站 - FastAPI 后端
基于 Kirameku 项目架构改造
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.responses import RedirectResponse

from config import settings
from routers import auth, relationship, lovelog, comment, media, map_point, milestone, wechat

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description=f"{settings.PROJECT_NAME} - 一个浪漫的恋爱记录网站后端",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS 中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in settings.CORS_ORIGINS.split(',')],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 根路由重定向
@app.get("/")
async def root():
    return RedirectResponse(url="/docs")

# 包含路由
app.include_router(auth.router, prefix="/auth", tags=["认证"])
app.include_router(relationship.router, prefix="/relationship", tags=["关系"])
app.include_router(lovelog.router, prefix="/records", tags=["记录"])
app.include_router(comment.router, prefix="/comments", tags=["评论"])
app.include_router(media.router, prefix="/media", tags=["媒体"])
app.include_router(map_point.router, prefix="/map-points", tags=["地图点位"])
app.include_router(milestone.router, prefix="/milestones", tags=["里程碑"])
app.include_router(wechat.router, prefix="/wechat", tags=["微信"])

@app.get("/health")
async def health_check():
    return {"status": "healthy", "project": settings.PROJECT_NAME}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
