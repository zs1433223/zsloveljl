<template>
  <div class="records-container">
    <el-card shadow="hover">
      <template #header>
        <div class="card-header">
          <span>📝 恋爱记录</span>
        </div>
      </template>

      <!-- 操作栏 -->
      <div class="actions">
        <el-button type="primary" @click="handleCreate">新建记录</el-button>
        <el-button @click="refresh">刷新</el-button>
      </div>

      <!-- 搜索栏 -->
      <div class="search-bar">
        <el-input
          v-model="keyword"
          placeholder="搜索标题或内容"
          prefix-icon="Search"
          style="width: 300px"
          clearable
          @clear="fetchRecords"
        />
        <el-select v-model="status" placeholder="全部状态" style="width: 120px" @change="fetchRecords">
          <el-option label="全部" value="" />
          <el-option label="草稿" value="draft" />
          <el-option label="已发布" value="published" />
          <el-option label="私密" value="private" />
        </el-select>
        <el-date-picker
          v-model="dateRange"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          value-format="YYYY-MM-DD"
          style="width: 280px"
          @change="fetchRecords"
        />
      </div>

      <!-- 表格 -->
      <el-table
        :data="records"
        style="width: 100%"
        stripe
        border
        v-loading="loading"
      >
        <el-table-column prop="title" label="标题" min-width="200">
          <template #default="scope">
            <el-link type="primary" @click="handleView(scope.row)">{{ scope.row.title }}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="record_date" label="记录日期" min-width="120">
          <template #default="scope">
            {{ formatDate(scope.row.record_date) }}
          </template>
        </el-table-column>
        <el-table-column prop="views" label="浏览量" min-width="100" />
        <el-table-column prop="likes" label="点赞数" min-width="100" />
        <el-table-column prop="status" label="状态" min-width="100">
          <template #default="scope">
            <el-tag
              :type="scope.row.status === 'published' ? 'success' : scope.row.status === 'draft' ? 'info' : 'danger'"
              effect="plain"
            >
              {{ scope.row.status === 'published' ? '已发布' : scope.row.status === 'draft' ? '草稿' : '私密' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" min-width="180">
          <template #default="scope">
            <el-button type="primary" size="small" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          :current-page="currentPage"
          :page-sizes="[10, 20, 50, 100]"
          :page-size="pageSize"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useRouter } from 'vue-router'
import { getLoveRecords, deleteLoveRecord } from '@/utils/api'

const router = useRouter()

// 表单数据
const keyword = ref('')
const status = ref('')
const dateRange = ref([])
const records = ref([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(10)
const loading = ref(false)

// 获取记录列表
const fetchRecords = async () => {
  loading.value = true
  try {
    const res = await getLoveRecords({
      keyword: keyword.value,
      status: status.value,
      start_date: dateRange.value[0] || undefined,
      end_date: dateRange.value[1] || undefined,
      page: currentPage.value,
      per_page: pageSize.value
    })
    records.value = res.items
    total.value = res.total
  } catch (e) {
    ElMessage.error('获取记录列表失败')
  } finally {
    loading.value = false
  }
}

// 新建记录
const handleCreate = () => {
  router.push('/records/create')
}

// 查看记录
const handleView = (row: any) => {
  router.push(`/records/${row.id}`)
}

// 编辑记录
const handleEdit = (row: any) => {
  router.push(`/records/${row.id}/edit`)
}

// 删除记录
const handleDelete = (row: any) => {
  ElMessageBox.confirm(
    `确定要删除记录 ${row.title} 吗？`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  ).then(async () => {
    try {
      await deleteLoveRecord(row.id)
      ElMessage.success('删除成功')
      fetchRecords()
    } catch (e) {
      ElMessage.error('删除失败')
    }
  })
}

// 刷新
const refresh = () => {
  fetchRecords()
}

// 分页事件
const handleSizeChange = (val: number) => {
  pageSize.value = val
  fetchRecords()
}

const handleCurrentChange = (val: number) => {
  currentPage.value = val
  fetchRecords()
}

// 格式化日期
const formatDate = (dateStr: string) => {
  const date = new Date(dateStr)
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-`
    + `${String(date.getDate()).padStart(2, '0')}`
}

onMounted(() => {
  fetchRecords()
})
</script>

<style scoped>
.records-container {
  padding: 20px;
}

.actions {
  margin-bottom: 20px;
}

.search-bar {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  align-items: center;
}

.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>
