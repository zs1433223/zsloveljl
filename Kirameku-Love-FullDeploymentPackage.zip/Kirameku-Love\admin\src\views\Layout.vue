<template>
  <el-container class="layout-container">
    <el-aside width="200px" class="aside">
      <div class="logo">💕 恋爱记录</div>
      <el-menu
        :default-active="route.path"
        router
        background-color="#fff"
        text-color="#333"
        active-text-color="#ff3366"
      >
        <el-menu-item index="/dashboard">
          <el-icon><DataAnalysis /></el-icon>
          <span>仪表盘</span>
        </el-menu-item>
        <el-menu-item index="/users">
          <el-icon><User /></el-icon>
          <span>用户管理</span>
        </el-menu-item>
        <el-menu-item index="/relationship">
          <el-icon><Heart /></el-icon>
          <span>关系管理</span>
        </el-menu-item>
        <el-menu-item index="/records">
          <el-icon><Document /></el-icon>
          <span>恋爱记录</span>
        </el-menu-item>
        <el-menu-item index="/map-points">
          <el-icon><Location /></el-icon>
          <span>地图点位</span>
        </el-menu-item>
        <el-menu-item index="/milestones">
          <el-icon><Trophy /></el-icon>
          <span>里程碑</span>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header class="header">
        <div class="header-title">{{ route.meta.title }}</div>
        <el-button type="danger" text @click="handleLogout">退出登录</el-button>
      </el-header>

      <el-main>
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()

const handleLogout = () => {
  localStorage.removeItem('token')
  router.push('/login')
}
</script>

<style scoped>
.layout-container {
  height: 100vh;
}

.aside {
  background: #fff;
  border-right: 1px solid #f0f0f0;
}

.logo {
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  font-weight: bold;
  color: #ff3366;
  border-bottom: 1px solid #f0f0f0;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fff;
  border-bottom: 1px solid #f0f0f0;
}

.header-title {
  font-size: 18px;
  font-weight: bold;
}
</style>
