"""
恋爱记录服务层
"""
from typing import List, Optional
from sqlmodel import Session, select
from sqlalchemy.orm import joinedload
from datetime import date

from models.lovelog import LoveRecord
from models.media import RecordMedia
from models.comment import Comment
from schemas import (
    LoveRecordCreate,
    LoveRecordUpdate,
    LoveRecordResponse,
    LoveRecordListResponse,
    RecordMediaCreate,
    RecordMediaResponse,
    CommentCreate,
    CommentResponse,
)


def get_love_records(
    db: Session,
    page: int = 1,
    per_page: int = 20,
    status: Optional[str] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
) -> LoveRecordListResponse:
    """获取恋爱记录列表（支持分页和筛选）"""
    query = select(LoveRecord)

    if status:
        query = query.where(LoveRecord.status == status)
    if start_date:
        query = query.where(LoveRecord.record_date >= start_date)
    if end_date:
        query = query.where(LoveRecord.record_date <= end_date)

    # 总数
    count = len(db.exec(query).all())

    # 分页
    query = (
        query
        .order_by(LoveRecord.record_date.desc(), LoveRecord.id.desc())
        .offset((page - 1) * per_page)
        .limit(per_page)
    )

    items = db.exec(query).all()

    return LoveRecordListResponse(
        total=count,
        items=[LoveRecordResponse.model_validate(r) for r in items]
    )


def get_love_record_by_id(db: Session, record_id: int) -> Optional[LoveRecordResponse]:
    """获取单条恋爱记录详情（含媒体和评论）"""
    record = db.get(LoveRecord, record_id)
    if not record:
        return None

    # 加载关联
    media = db.exec(
        select(RecordMedia).where(RecordMedia.record_id == record_id)
    ).all()
    comments = db.exec(
        select(Comment)
        .where(Comment.record_id == record_id, Comment.status == "approved")
        .order_by(Comment.created_at.desc())
    ).all()

    return LoveRecordResponse(
        id=record.id,
        title=record.title,
        content=record.content,
        record_date=record.record_date,
        is_private=record.is_private,
        status=record.status,
        views=record.views,
        likes=record.likes,
        media=[RecordMediaResponse.model_validate(m) for m in media],
        comments=[CommentResponse.model_validate(c) for c in comments],
        created_at=record.created_at,
        updated_at=record.updated_at,
    )


def create_love_record(db: Session, data: LoveRecordCreate) -> LoveRecordResponse:
    """创建恋爱记录"""
    record = LoveRecord(**data.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return LoveRecordResponse.model_validate(record)


def update_love_record(
    db: Session, record_id: int, data: LoveRecordUpdate
) -> Optional[LoveRecordResponse]:
    """更新恋爱记录"""
    record = db.get(LoveRecord, record_id)
    if not record:
        return None

    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(record, key, value)

    db.add(record)
    db.commit()
    db.refresh(record)
    return LoveRecordResponse.model_validate(record)


def delete_love_record(db: Session, record_id: int) -> bool:
    """删除恋爱记录（级联删除媒体和评论）"""
    record = db.get(LoveRecord, record_id)
    if not record:
        return False

    # 删除关联媒体
    media_list = db.exec(select(RecordMedia).where(RecordMedia.record_id == record_id)).all()
    for m in media_list:
        db.delete(m)

    # 删除关联评论
    comments_list = db.exec(select(Comment).where(Comment.record_id == record_id)).all()
    for c in comments_list:
        db.delete(c)

    db.delete(record)
    db.commit()
    return True


def increment_views(db: Session, record_id: int):
    """增加浏览量"""
    record = db.get(LoveRecord, record_id)
    if record:
        record.views += 1
        db.add(record)
        db.commit()
