"""
关系服务层
"""
from typing import Optional
from sqlmodel import Session, select

from models.relationship import Relationship
from schemas import RelationshipCreate, RelationshipUpdate, RelationshipResponse


def get_relationship(db: Session) -> Optional[RelationshipResponse]:
    """获取情侣关系信息"""
    rel = db.exec(select(Relationship)).first()
    if not rel:
        return None

    return RelationshipResponse(
        id=rel.id,
        partner1_name=rel.partner1_name,
        partner1_avatar=rel.partner1_avatar,
        partner1_birthday=rel.partner1_birthday,
        partner2_name=rel.partner2_name,
        partner2_avatar=rel.partner2_avatar,
        partner2_birthday=rel.partner2_birthday,
        start_date=rel.start_date,
        together_days=rel.together_days,
        birthday_countdown=rel.birthday_countdown,
        created_at=rel.created_at,
        updated_at=rel.updated_at,
    )


def init_relation(db: Session, data: RelationshipCreate) -> RelationshipResponse:
    """初始化情侣关系（首次设置）"""
    existing = db.exec(select(Relationship)).first()
    if existing:
        raise Exception("关系已存在，请使用更新接口")

    rel = Relationship(**data.model_dump())
    db.add(rel)
    db.commit()
    db.refresh(rel)

    return RelationshipResponse(
        id=rel.id,
        partner1_name=rel.partner1_name,
        partner1_avatar=rel.partner1_avatar,
        partner1_birthday=rel.partner1_birthday,
        partner2_name=rel.partner2_name,
        partner2_avatar=rel.partner2_avatar,
        partner2_birthday=rel.partner2_birthday,
        start_date=rel.start_date,
        together_days=rel.together_days,
        birthday_countdown=rel.birthday_countdown,
        created_at=rel.created_at,
        updated_at=rel.updated_at,
    )


def update_relationship(
    db: Session, rel_id: int, data: RelationshipUpdate
) -> Optional[RelationshipResponse]:
    """更新情侣关系"""
    rel = db.get(Relationship, rel_id)
    if not rel:
        return None

    for key, value in data.model_dump(exclude_unset=True).items():
        setattr(rel, key, value)

    db.add(rel)
    db.commit()
    db.refresh(rel)

    return RelationshipResponse(
        id=rel.id,
        partner1_name=rel.partner1_name,
        partner1_avatar=rel.partner1_avatar,
        partner1_birthday=rel.partner1_birthday,
        partner2_name=rel.partner2_name,
        partner2_avatar=rel.partner2_avatar,
        partner2_birthday=rel.partner2_birthday,
        start_date=rel.start_date,
        together_days=rel.together_days,
        birthday_countdown=rel.birthday_countdown,
        created_at=rel.created_at,
        updated_at=rel.updated_at,
    )
