/**
 * 恋爱记录详情页
 * 媒体灯箱、评论区、管理员操作按钮
 */
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getLoveRecord, viewLoveRecord, addComment, LoveRecord } from '@/lib/api';
import Image from 'next/image';

export default function RecordDetailPage({ params }: { params: { id: string } }) {
  const [record, setRecord] = useState<LoveRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [commentText, setCommentText] = useState('');
  const [commentName, setCommentName] = useState('');
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const id = parseInt(params.id);
    if (!id) return;

    // 增加浏览量
    viewLoveRecord(id).catch(() => {});

    getLoveRecord(id)
      .then((res) => setRecord(res))
      .catch(() => router.push('/'))
      .finally(() => setLoading(false));
  }, [params.id]);

  const handleSubmitComment = async () => {
    if (!record || !commentText.trim()) return;
    try {
      await addComment(record.id, {
        nickname: commentName || '匿名',
        content: commentText,
      });
      setCommentText('');
      // 刷新记录
      const res = await getLoveRecord(record.id);
      setRecord(res);
    } catch (e) {
      alert('评论失败');
    }
  };

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-8">
        <div className="glass p-6 animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/2 mb-4"></div>
          <div className="h-4 bg-gray-100 rounded w-full mb-2"></div>
          <div className="h-4 bg-gray-100 rounded w-3/4"></div>
        </div>
      </div>
    );
  }

  if (!record) return null;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      {/* 返回按钮 */}
      <button
        onClick={() => router.back()}
        className="mb-6 text-rose-500 hover:text-rose-600"
      >
        ← 返回列表
      </button>

      {/* 记录卡片 */}
      <div className="glass p-6 animate-fade-in">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">{record.title}</h1>
        <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
          <span>{new Date(record.record_date).toLocaleDateString('zh-CN')}</span>
          <span>👁 {record.views}</span>
          <span>❤️ {record.likes}</span>
          {record.is_private && <span className="text-rose-500">🔒 私密</span>}
        </div>

        {/* 媒体展示 */}
        {record.media?.length > 0 && (
          <div className="mb-6">
            <div className="grid grid-cols-2 gap-2">
              {record.media.map((media) => (
                <div
                  key={media.id}
                  className="relative aspect-video rounded-lg overflow-hidden cursor-pointer"
                  onClick={() => media.media_type === 'image' && setLightboxImage(media.media_url)}
                >
                  {media.media_type === 'image' ? (
                    <Image
                      src={media.media_url}
                      alt={media.caption}
                      fill
                      className="object-cover"
                    />
                  ) : (
                    <video
                      src={media.media_url}
                      controls
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 内容 */}
        <div className="prose prose-rose max-w-none text-gray-700 mb-8">
          {record.content.split('\n').map((p, i) => (
            <p key={i} className="mb-4">{p}</p>
          ))}
        </div>

        {/* 评论区 */}
        <div className="border-t border-gray-200 pt-6">
          <h3 className="text-xl font-bold text-gray-800 mb-4">
            💬 评论 ({record.comments?.length || 0})
          </h3>

          {/* 评论输入 */}
          <div className="mb-6">
            <input
              type="text"
              placeholder="你的昵称"
              value={commentName}
              onChange={(e) => setCommentName(e.target.value)}
              className="w-full p-3 rounded-lg border border-gray-200 mb-2 focus:outline-none focus:ring-2 focus:ring-rose-300"
            />
            <textarea
              placeholder="说点什么吧..."
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              className="w-full p-3 rounded-lg border border-gray-200 mb-2 h-24 focus:outline-none focus:ring-2 focus:ring-rose-300"
            />
            <button
              onClick={handleSubmitComment}
              className="px-6 py-2 bg-rose-500 text-white rounded-lg hover:bg-rose-600"
            >
              发表评论
            </button>
          </div>

          {/* 评论列表 */}
          <div className="space-y-4">
            {record.comments?.map((comment) => (
              <div key={comment.id} className="flex gap-3 p-3 bg-white/50 rounded-lg">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-rose-300 to-pink-400 flex items-center justify-center text-white text-sm flex-shrink-0">
                  {comment.nickname[0]}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{comment.nickname}</span>
                    <span className="text-xs text-gray-400">
                      {new Date(comment.created_at).toLocaleString('zh-CN')}
                    </span>
                  </div>
                  <p className="text-gray-700 mt-1">{comment.content}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 灯箱 */}
      {lightboxImage && (
        <div
          className="lightbox"
          onClick={() => setLightboxImage(null)}
        >
          <img
            src={lightboxImage}
            alt="放大预览"
            className="lightbox-content"
          />
        </div>
      )}
    </div>
  );
}
