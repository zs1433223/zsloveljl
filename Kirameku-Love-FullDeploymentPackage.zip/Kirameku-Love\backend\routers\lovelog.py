"""
恋爱记录路由
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlmodel import Session
from typing import Optional
from datetime import date

from database import get_db
from services import lovelog_service
from schemas import (
    LoveRecordCreate,
    LoveRecordUpdate,
    LoveRecordResponse,
    LoveRecordListResponse,
    CommentCreate,
    CommentResponse,
)

router = APIRouter()


@router.get("/", response_model=LoveRecordListResponse)
def list_love_records(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    status: Optional[str] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: Session = Depends(get_db),
):
    """获取恋爱记录列表（支持分页和筛选）"""
    return lovelog_service.get_love_records(
        db, page=page, per_page=per_page, status=status,
        start_date=start_date, end_date=end_date,
    )


@router.get("/{record_id}", response_model=LoveRecordResponse)
def get_love_record(record_id: int, db: Session = Depends(get_db)):
    """获取单条恋爱记录详情（含媒体和评论）"""
    record = lovelog_service.get_love_record_by_id(db, record_id)
    if not record:
        raise HTTPException(status_code=404, detail="记录不存在")
    return record


@router.post("/", response_model=LoveRecordResponse)
def create_love_record(data: LoveRecordCreate, db: Session = Depends(get_db)):
    """创建恋爱记录（仅管理员）"""
    return lovelog_service.create_love_record(db, data)


@router.put("/{record_id}", response_model=LoveRecordResponse)
def update_love_record(
    record_id: int, data: LoveRecordUpdate, db: Session = Depends(get_db)
):
    """更新恋爱记录（仅管理员）"""
    record = lovelog_service.update_love_record(db, record_id, data)
    if not record:
        raise HTTPException(status_code=404, detail="记录不存在")
    return record


@router.delete("/{record_id}")
def delete_love_record(record_id: int, db: Session = Depends(get_db)):
    """删除恋爱记录（仅管理员）"""
    success = lovelog_service.delete_love_record(db, record_id)
    if not success:
        raise HTTPException(status_code=404, detail="记录不存在")
    return {"message": "删除成功"}


@router.post("/{record_id}/view")
def view_love_record(record_id: int, db: Session = Depends(get_db)):
    """增加记录浏览量"""
    lovelog_service.increment_views(db, record_id)
    return {"message": "浏览成功"}


@router.post("/{record_id}/comments", response_model=CommentResponse)
def add_comment(record_id: int, data: CommentCreate, db: Session = Depends(get_db)):
    """为记录添加评论"""
    from models.comment import Comment
    comment = Comment(
        record_id=record_id,
        parent_id=data.parent_id,
        nickname=data.nickname,
        avatar=data.avatar,
        content=data.content,
        status="approved",  # 自动通过
    )
    db.add(comment)
    db.commit()
    db.refresh(comment)
    return CommentResponse.model_validate(comment)
