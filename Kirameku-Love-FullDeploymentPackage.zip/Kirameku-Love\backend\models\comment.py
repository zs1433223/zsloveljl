"""
评论模型
"""
from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import datetime


class Comment(SQLModel, table=True):
    __tablename__ = "comments"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    record_id: int = Field(foreign_key="loverecords.id", index=True)
    parent_id: Optional[int] = Field(default=None, foreign_key="comments.id")
    nickname: str = Field(max_length=50)
    avatar: str = Field(default="", max_length=500)
    content: str
    ip: str = Field(default="", max_length=45)
    status: str = Field(default="pending", max_length=20)  # pending, approved, rejected
    likes: int = Field(default=0)
    created_at: datetime = Field(default_factory=datetime.now)
