import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 10000,
})

// 请求拦截器 - 添加 token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// 响应拦截器 - 处理错误
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// ===== 认证相关 =====
export const login = (data: { username: string; password: string }) =>
  api.post('/auth/login', data)

// ===== 地图点位相关 =====
export interface MapPoint {
  id: number
  name: string
  description: string
  longitude: number
  latitude: number
  city: string
  province: string
  country: string
  point_type: string
  cover_image: string
  photos: string[]
  videos: string[]
  sort_order: number
  status: string
  created_at: string
  updated_at: string
}

export interface MapPointsParams {
  keyword?: string
  city?: string
  province?: string
  point_type?: string
  page?: number
  per_page?: number
}

export const getMapPoints = (params?: MapPointsParams) =>
  api.get('/map-points', { params })

export const getMapPoint = (id: number) =>
  api.get(`/map-points/${id}`)

export const createMapPoint = (data: Omit<MapPoint, 'id' | 'created_at' | 'updated_at'>) =>
  api.post('/map-points', data)

export const updateMapPoint = (id: number, data: Partial<MapPoint>) =>
  api.put(`/map-points/${id}`, data)

export const deleteMapPoint = (id: number) =>
  api.delete(`/map-points/${id}`)

// ===== 里程碑相关 =====
export interface Milestone {
  id: number
  title: string
  description: string
  milestone_type: string
  achieved_date: string | null
  is_completed: boolean
  parent_id: number | null
  sort_order: number
  created_at: string
  updated_at: string
}

export const getMilestones = (params?: { page?: number; per_page?: number }) =>
  api.get('/milestones', { params })

export const getMilestone = (id: number) =>
  api.get(`/milestones/${id}`)

export const createMilestone = (data: Omit<Milestone, 'id' | 'created_at' | 'updated_at'>) =>
  api.post('/milestones', data)

export const updateMilestone = (id: number, data: Partial<Milestone>) =>
  api.put(`/milestones/${id}`, data)

export const deleteMilestone = (id: number) =>
  api.delete(`/milestones/${id}`)

// ===== 用户相关 =====
export interface User {
  id: number
  username: string
  nickname: string
  avatar: string
  wechat_id: string
  email: string
  role: string
  bio: string
  created_at: string
  updated_at: string
}

export const getUsers = (params?: { page?: number; per_page?: number; keyword?: string }) =>
  api.get('/users', { params })

export const getUser = (id: number) =>
  api.get(`/users/${id}`)

export const createUser = (data: Omit<User, 'id' | 'created_at' | 'updated_at'>) =>
  api.post('/users', data)

export const updateUser = (id: number, data: Partial<User>) =>
  api.put(`/users/${id}`, data)

export const deleteUser = (id: number) =>
  api.delete(`/users/${id}`)

// ===== 关系相关 =====
export interface Relationship {
  id: number
  partner1_name: string
  partner1_avatar: string
  partner1_birthday: string | null
  partner2_name: string
  partner2_avatar: string
  partner2_birthday: string | null
  start_date: string
  together_days: number
  birthday_countdown: Record<string, number>
  created_at: string
  updated_at: string
}

export const getRelationship = () =>
  api.get('/relationship')

export const updateRelationship = (data: Partial<Relationship>) =>
  api.put('/relationship', data)

// ===== 恋爱记录相关 =====
export interface LoveRecord {
  id: number
  title: string
  content: string
  record_date: string
  is_private: boolean
  status: string
  views: number
  likes: number
  media: any[]
  comments: any[]
  created_at: string
  updated_at: string
}

export const getRecords = (params?: { page?: number; per_page?: number; keyword?: string }) =>
  api.get('/love-records', { params })

export const getRecord = (id: number) =>
  api.get(`/love-records/${id}`)

export const createRecord = (data: Omit<LoveRecord, 'id' | 'created_at' | 'updated_at'>) =>
  api.post('/love-records', data)

export const updateRecord = (id: number, data: Partial<LoveRecord>) =>
  api.put(`/love-records/${id}`, data)

export const deleteRecord = (id: number) =>
  api.delete(`/love-records/${id}`)

export default api
