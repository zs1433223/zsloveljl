<template>
  <div class="map-points-container">
    <el-card shadow="hover">
      <template #header>
        <div class="card-header">
          <span>📍 地图点位</span>
        </div>
      </template>

      <!-- 操作栏 -->
      <div class="actions">
        <el-button type="primary" @click="handleCreate">新建点位</el-button>
        <el-button @click="refresh">刷新</el-button>
      </div>

      <!-- 搜索栏 -->
      <div class="search-bar">
        <el-input
          v-model="keyword"
          placeholder="搜索名称或城市"
          prefix-icon="Search"
          style="width: 300px"
          clearable
          @clear="fetchMapPoints"
        />
        <el-select v-model="city" placeholder="全部城市" style="width: 120px" @change="fetchMapPoints">
          <el-option label="全部" value="" />
          <el-option label="北京" value="北京" />
          <el-option label="上海" value="上海" />
          <el-option label="广州" value="广州" />
          <el-option label="深圳" value="深圳" />
        </el-select>
        <el-select v-model="pointType" placeholder="全部类型" style="width: 120px" @change="fetchMapPoints">
          <el-option label="全部" value="" />
          <el-option label="约会" value="date" />
          <el-option label="旅行" value="travel" />
          <el-option label="纪念" value="anniversary" />
        </el-select>
      </div>

      <!-- 表格 -->
      <el-table
        :data="mapPoints"
        style="width: 100%"
        stripe
        border
        v-loading="loading"
      >
        <el-table-column prop="name" label="名称" min-width="150">
          <template #default="scope">
            <el-link type="primary" @click="handleView(scope.row)">{{ scope.row.name }}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="city" label="城市" min-width="100" />
        <el-table-column prop="province" label="省份" min-width="100" />
        <el-table-column prop="point_type" label="类型" min-width="100">
          <template #default="scope">
            <el-tag
              :type="scope.row.point_type === 'date' ? 'primary' : scope.row.point_type === 'travel' ? 'success' : 'warning'"
              effect="plain"
            >
              {{ scope.row.point_type === 'date' ? '约会' : scope.row.point_type === 'travel' ? '旅行' : '纪念' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="longitude" label="经度" min-width="100" />
        <el-table-column prop="latitude" label="纬度" min-width="100" />
        <el-table-column label="操作" min-width="180">
          <template #default="scope">
            <el-button type="primary" size="small" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          :current-page="currentPage"
          :page-sizes="[10, 20, 50, 100]"
          :page-size="pageSize"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useRouter } from 'vue-router'
import { getMapPoints, deleteMapPoint } from '@/utils/api'

const router = useRouter()

// 表单数据
const keyword = ref('')
const city = ref('')
const pointType = ref('')
const mapPoints = ref([])
const total = ref(0)
const currentPage = ref(1)
const pageSize = ref(10)
const loading = ref(false)

// 获取地图点位列表
const fetchMapPoints = async () => {
  loading.value = true
  try {
    const res = await getMapPoints({
      keyword: keyword.value,
      city: city.value,
      point_type: pointType.value,
      page: currentPage.value,
      per_page: pageSize.value
    })
    mapPoints.value = res
    total.value = res.length
  } catch (e) {
    ElMessage.error('获取点位列表失败')
  } finally {
    loading.value = false
  }
}

// 新建点位
const handleCreate = () => {
  router.push('/map-points/create')
}

// 查看点位
const handleView = (row: any) => {
  router.push(`/map-points/${row.id}`)
}

// 编辑点位
const handleEdit = (row: any) => {
  router.push(`/map-points/${row.id}/edit`)
}

// 删除点位
const handleDelete = (row: any) => {
  ElMessageBox.confirm(
    `确定要删除点位 ${row.name} 吗？`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  ).then(async () => {
    try {
      await deleteMapPoint(row.id)
      ElMessage.success('删除成功')
      fetchMapPoints()
    } catch (e) {
      ElMessage.error('删除失败')
    }
  })
}

// 刷新
const refresh = () => {
  fetchMapPoints()
}

// 分页事件
const handleSizeChange = (val: number) => {
  pageSize.value = val
  fetchMapPoints()
}

const handleCurrentChange = (val: number) => {
  currentPage.value = val
  fetchMapPoints()
}

onMounted(() => {
  fetchMapPoints()
})
</script>

<style scoped>
.map-points-container {
  padding: 20px;
}

.actions {
  margin-bottom: 20px;
}

.search-bar {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  align-items: center;
}

.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>
