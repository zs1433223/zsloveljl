"""
数据库连接与会话管理
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlmodel import SQLModel, Session

from config import settings

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(class_=Session, autocommit=False, autoflush=False, bind=engine)


def get_db():
    """FastAPI 依赖注入 - 获取数据库会话"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """初始化数据库表结构"""
    # 导入所有模型确保注册
    from models.user import User
    from models.relationship import Relationship
    from models.lovelog import LoveRecord
    from models.comment import Comment
    from models.milestone import Milestone
    from models.map_point import MapPoint
    from models.media import RecordMedia

    SQLModel.metadata.create_all(bind=engine)
