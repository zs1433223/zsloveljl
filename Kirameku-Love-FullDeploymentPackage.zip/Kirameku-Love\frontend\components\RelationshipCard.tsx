/**
 * RelationshipCard 组件
 * 展示双头像、在一起天数、生日倒计时
 */
'use client';

import { useState, useEffect } from 'react';
import { getRelationship } from '@/lib/api';

interface RelationshipData {
  partner1_name: string;
  partner1_avatar: string;
  partner1_birthday?: string;
  partner2_name: string;
  partner2_avatar: string;
  partner2_birthday?: string;
  start_date: string;
  together_days: number;
  birthday_countdown: {
    partner1: number | null;
    partner2: number | null;
  };
}

export default function RelationshipCard() {
  const [data, setData] = useState<RelationshipData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getRelationship()
      .then((res) => setData(res))
      .catch(() => {
        // 如果接口失败，使用默认数据
        setData({
          partner1_name: '他/她',
          partner1_avatar: '',
          partner2_name: '我',
          partner2_avatar: '',
          start_date: '2024-01-01',
          together_days: 365,
          birthday_countdown: { partner1: 50, partner2: 120 },
        });
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="glass p-8 animate-pulse">
        <div className="flex justify-center items-center gap-8">
          <div className="w-24 h-24 rounded-full bg-gray-200"></div>
          <div className="text-4xl font-bold text-rose-300">0</div>
          <div className="w-24 h-24 rounded-full bg-gray-200"></div>
        </div>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="glass p-8 animate-fade-in">
      <div className="flex flex-col items-center">
        {/* 头部标题 */}
        <h1 className="text-4xl font-bold text-rose-600 mb-2">
          💕 我们的恋爱时光 💕
        </h1>
        <p className="text-gray-500 mb-8">
          从 {new Date(data.start_date).toLocaleDateString('zh-CN')} 开始
        </p>

        {/* 双头像 + 在一起天数 */}
        <div className="flex items-center justify-center gap-8 mb-10">
          {/* 伴侣1 */}
          <div className="flex flex-col items-center">
            <div className="relative">
              {data.partner1_avatar ? (
                <img
                  src={data.partner1_avatar}
                  alt={data.partner1_name}
                  className="w-24 h-24 rounded-full object-cover border-4 border-rose-300"
                />
              ) : (
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-rose-300 to-rose-500 flex items-center justify-center text-white text-2xl font-bold">
                  {data.partner1_name[0]}
                </div>
              )}
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-rose-500 rounded-full flex items-center justify-center text-white text-xs">
                ♡
              </div>
            </div>
            <span className="mt-2 text-lg font-semibold text-gray-700">
              {data.partner1_name}
            </span>
          </div>

          {/* 在一起天数 */}
          <div className="flex flex-col items-center px-8">
            <div className="text-6xl font-bold text-rose-500 animate-pulse-slow">
              {data.together_days}
            </div>
            <div className="text-xl text-gray-500 mt-1">天</div>
            <div className="mt-4 text-sm text-rose-400 font-medium">
              我们已经在一起
            </div>
          </div>

          {/* 伴侣2 */}
          <div className="flex flex-col items-center">
            <div className="relative">
              {data.partner2_avatar ? (
                <img
                  src={data.partner2_avatar}
                  alt={data.partner2_name}
                  className="w-24 h-24 rounded-full object-cover border-4 border-rose-300"
                />
              ) : (
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-pink-300 to-pink-500 flex items-center justify-center text-white text-2xl font-bold">
                  {data.partner2_name[0]}
                </div>
              )}
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-pink-500 rounded-full flex items-center justify-center text-white text-xs">
                ♡
              </div>
            </div>
            <span className="mt-2 text-lg font-semibold text-gray-700">
              {data.partner2_name}
            </span>
          </div>
        </div>

        {/* 生日倒计时 */}
        <div className="flex gap-12">
          {data.birthday_countdown.partner1 !== null && (
            <div className="flex flex-col items-center">
              <div className="text-sm text-gray-500 mb-1">
                {data.partner1_name} 的生日倒计时
              </div>
              <div className="countdown-bar w-32">
                <div
                  className="countdown-bar-fill"
                  style={{ width: `${Math.max(5, (data.birthday_countdown.partner1 / 365) * 100)}%` }}
                />
              </div>
              <div className="mt-1 text-rose-500 font-semibold">
                {data.birthday_countdown.partner1} 天后
              </div>
            </div>
          )}

          {data.birthday_countdown.partner2 !== null && (
            <div className="flex flex-col items-center">
              <div className="text-sm text-gray-500 mb-1">
                {data.partner2_name} 的生日倒计时
              </div>
              <div className="countdown-bar w-32">
                <div
                  className="countdown-bar-fill"
                  style={{ width: `${Math.max(5, (data.birthday_countdown.partner2 / 365) * 100)}%` }}
                />
              </div>
              <div className="mt-1 text-pink-500 font-semibold">
                {data.birthday_countdown.partner2} 天后
              </div>
            </div>
          )}
        </div>

        {/* 浪漫引用 */}
        <div className="mt-10 text-center text-gray-600 italic">
          <p>"执子之手，与子偕老"</p>
          <p className="text-sm mt-1 text-gray-400">—— 记录每一个美好的瞬间</p>
        </div>
      </div>
    </div>
  );
}
