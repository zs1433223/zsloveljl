"""
应用配置 - 恋爱记录网站后端
"""
import os
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # 数据库
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./love_database.db")

    # 应用密钥
    SECRET_KEY: str = os.getenv("SECRET_KEY", "your-secret-key-here-change-in-production")

    # CORS
    CORS_ORIGINS: str = os.getenv("CORS_ORIGINS", "http://localhost:3000,http://localhost:5173")

    # 微信开放平台
    WECHAT_APPID: str = os.getenv("WECHAT_APPID", "")
    WECHAT_SECRET: str = os.getenv("WECHAT_SECRET", "")

    # 高德地图
    AMAP_WEB_SERVICE_KEY: str = os.getenv("AMAP_WEB_SERVICE_KEY", "")

    # 阿里云 OSS
    OSS_ACCESS_KEY_ID: str = os.getenv("OSS_ACCESS_KEY_ID", "")
    OSS_ACCESS_KEY_SECRET: str = os.getenv("OSS_ACCESS_KEY_SECRET", "")
    OSS_BUCKET_NAME: str = os.getenv("OSS_BUCKET_NAME", "")
    OSS_ENDPOINT: str = os.getenv("OSS_ENDPOINT", "")
    OSS_CUSTOM_DOMAIN: str = os.getenv("OSS_CUSTOM_DOMAIN", "")
    OSS_PREFIX: str = os.getenv("OSS_PREFIX", "Love/")

    # 存储配置
    STORAGE_TYPE: str = os.getenv("STORAGE_TYPE", "oss")  # local 或 oss
    UPLOAD_DIR: str = os.getenv("UPLOAD_DIR", "./uploads")
    
    # 项目配置
    PROJECT_NAME: str = "Kirameku-Love"
    VERSION: str = "1.0.0"
    AUTHOR: str = "Xinghongia"
    LICENSE: str = "MIT"
    
    # 路由配置
    ROUTES: dict = {
        "home": "/",
        "dashboard": "/dashboard",
        "records": "/records",
        "record_detail": "/records/{id}",
        "relationship": "/relationship",
        "map": "/map",
        "milestones": "/milestones",
        "login": "/login",
        "admin": "/admin",
        "admin_dashboard": "/admin/dashboard",
        "admin_users": "/admin/users",
        "admin_records": "/admin/records",
        "admin_map_points": "/admin/map-points",
        "admin_milestones": "/admin/milestones",
    }
    
    # API 接口配置
    API: dict = {
        "baseUrl": "http://localhost:8000/api",
        "auth": {
            "login": "/auth/login",
            "logout": "/auth/logout",
            "refreshToken": "/auth/refresh",
        },
        "relationship": {
            "get": "/relationship",
            "update": "/relationship",
        },
        "records": {
            "list": "/records",
            "detail": "/records/{id}",
            "create": "/records",
            "update": "/records/{id}",
            "delete": "/records/{id}",
            "view": "/records/{id}/view",
            "comment": "/records/{id}/comments",
        },
        "map_points": {
            "list": "/map-points",
            "detail": "/map-points/{id}",
            "create": "/map-points",
            "update": "/map-points/{id}",
            "delete": "/map-points/{id}",
        },
        "milestones": {
            "list": "/milestones",
            "detail": "/milestones/{id}",
            "create": "/milestones",
            "update": "/milestones/{id}",
            "delete": "/milestones/{id}",
        },
        "users": {
            "list": "/users",
            "detail": "/users/{id}",
            "create": "/users",
            "update": "/users/{id}",
            "delete": "/users/{id}",
        },
        "media": {
            "upload": "/media/upload",
            "delete": "/media/delete",
        },
    }
    
    # 常量配置
    CONSTANTS: dict = {
        # 页面大小
        "PAGE_SIZE": 10,
        "MAX_PAGE_SIZE": 100,
        
        # 时间格式
        "DATE_FORMAT": "YYYY-MM-DD",
        "DATETIME_FORMAT": "YYYY-MM-DD HH:mm:ss",
        
        # 状态码
        "STATUS_CODE": {
            "SUCCESS": 200,
            "CREATED": 201,
            "BAD_REQUEST": 400,
            "UNAUTHORIZED": 401,
            "FORBIDDEN": 403,
            "NOT_FOUND": 404,
            "SERVER_ERROR": 500,
        },
        
        # 角色
        "ROLES": {
            "ADMIN": "admin",
            "USER": "user",
        },
        
        # 点位类型
        "POINT_TYPES": {
            "DATE": "date",
            "TRAVEL": "travel",
            "ANNIVERSARY": "anniversary",
        },
        
        # 里程碑类型
        "MILESTONE_TYPES": {
            "ACHIEVEMENT": "achievement",
            "LOCATION": "location",
            "SPECIAL": "special",
        },
        
        # 记录状态
        "RECORD_STATUS": {
            "DRAFT": "draft",
            "PUBLISHED": "published",
            "PRIVATE": "private",
        },
        
        # 默认头像
        "DEFAULT_AVATARS": [
            "https://picsum.photos/id/1/200/200",
            "https://picsum.photos/id/2/200/200",
            "https://picsum.photos/id/3/200/200",
            "https://picsum.photos/id/4/200/200",
            "https://picsum.photos/id/5/200/200",
        ],
    }

    class Config:
        env_file = ".env"


settings = Settings()
