"""
评论路由
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from typing import List

from database import get_db
from models.comment import Comment
from schemas import CommentResponse, CommentCreate

router = APIRouter()


@router.get("/record/{record_id}", response_model=List[CommentResponse])
def list_comments_for_record(record_id: int, db: Session = Depends(get_db)):
    """获取某条记录的所有已批准评论"""
    comments = db.exec(
        select(Comment)
        .where(Comment.record_id == record_id, Comment.status == "approved")
        .order_by(Comment.created_at.desc())
    ).all()
    return [CommentResponse.model_validate(c) for c in comments]


@router.get("/{comment_id}", response_model=CommentResponse)
def get_comment(comment_id: int, db: Session = Depends(get_db)):
    """获取单条评论"""
    comment = db.get(Comment, comment_id)
    if not comment:
        raise HTTPException(status_code=404, detail="评论不存在")
    return CommentResponse.model_validate(comment)


@router.delete("/{comment_id}")
def delete_comment(comment_id: int, db: Session = Depends(get_db)):
    """删除评论（仅管理员）"""
    comment = db.get(Comment, comment_id)
    if not comment:
        raise HTTPException(status_code=404, detail="评论不存在")
    db.delete(comment)
    db.commit()
    return {"message": "评论已删除"}
