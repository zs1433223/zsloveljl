"""
记录媒体模型
"""
from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import datetime


class RecordMedia(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    record_id: int = Field(foreign_key="loverecords.id", index=True)
    media_type: str = Field(max_length=20)  # image, video
    media_url: str = Field(max_length=500)
    caption: str = Field(default="", max_length=200)
    sort_order: int = Field(default=0)
    created_at: datetime = Field(default_factory=datetime.now)
