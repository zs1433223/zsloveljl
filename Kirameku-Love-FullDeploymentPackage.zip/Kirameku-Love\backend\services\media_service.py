"""
媒体上传服务
"""
import os
import uuid
import shutil
from typing import Optional
from fastapi import UploadFile
from config import settings


def save_upload_file(file: UploadFile, sub_dir: str = "media") -> str:
    """
    保存上传文件到本地存储
    返回相对路径
    """
    # 生成唯一文件名
    file_ext = os.path.splitext(file.filename)[1].lower()
    unique_name = f"{uuid.uuid4().hex}{file_ext}"
    relative_path = f"{sub_dir}/{unique_name}"
    full_path = os.path.join(settings.UPLOAD_DIR, relative_path)

    # 确保目录存在
    os.makedirs(os.path.dirname(full_path), exist_ok=True)

    # 保存文件
    with open(full_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    return relative_path


def upload_to_oss(file: UploadFile, sub_dir: str = "media") -> str:
    """
    上传文件到阿里云 OSS
    返回 CDN URL
    """
    import oss2

    if not settings.OSS_ACCESS_KEY_ID or not settings.OSS_ACCESS_KEY_SECRET:
        raise Exception("OSS 配置缺失")

    auth = oss2.Auth(settings.OSS_ACCESS_KEY_ID, settings.OSS_ACCESS_KEY_SECRET)
    bucket = oss2.Bucket(auth, settings.OSS_ENDPOINT, settings.OSS_BUCKET_NAME)

    # 生成唯一文件名
    file_ext = os.path.splitext(file.filename)[1].lower()
    unique_name = f"{uuid.uuid4().hex}{file_ext}"
    object_key = f"{settings.OSS_PREFIX}{sub_dir}/{unique_name}"

    # 上传
    bucket.put_object(object_key, file.file)

    # 返回 URL
    if settings.OSS_CUSTOM_DOMAIN:
        return f"{settings.OSS_CUSTOM_DOMAIN.rstrip('/')}/{object_key}"
    else:
        return f"https://{settings.OSS_BUCKET_NAME}.{settings.OSS_ENDPOINT}/{object_key}"


def upload_file(file: UploadFile, sub_dir: str = "media") -> str:
    """
    统一上传接口 - 根据配置选择本地或 OSS
    """
    if settings.STORAGE_TYPE == "oss":
        return upload_to_oss(file, sub_dir)
    else:
        return save_upload_file(file, sub_dir)


def get_file_url(relative_path: str) -> str:
    """获取文件访问 URL"""
    if settings.STORAGE_TYPE == "oss":
        # OSS 文件返回 CDN URL
        object_key = f"{settings.OSS_PREFIX}{relative_path}"
        if settings.OSS_CUSTOM_DOMAIN:
            return f"{settings.OSS_CUSTOM_DOMAIN.rstrip('/')}/{object_key}"
        else:
            return f"https://{settings.OSS_BUCKET_NAME}.{settings.OSS_ENDPOINT}/{object_key}"
    else:
        # 本地文件返回静态路径
        return f"/uploads/{relative_path}"
