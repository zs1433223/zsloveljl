"""
路由模块导出
"""
from routers import user, relationship, lovelog, comment, media, map_point, milestone, wechat

__all__ = [
    "user",
    "relationship",
    "lovelog",
    "comment",
    "media",
    "map_point",
    "milestone",
    "wechat",
]
