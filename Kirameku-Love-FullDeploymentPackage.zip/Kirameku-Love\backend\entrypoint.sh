#!/bin/bash
set -e

echo "🚀 Starting backend entrypoint..."

# 等待数据库就绪（健康检查已在 docker-compose 做，这里双保险）
echo "⏳ Waiting for database..."
until pg_isready -h postgres -U love_user -d love_db > /dev/null 2>&1; do
  sleep 2
done
echo "✅ Database is ready"

# 自动运行数据库迁移（如果有 Alembic）
if [ -f "alembic.ini" ]; then
  echo "🔄 Running database migrations..."
  alembic upgrade head
  echo "✅ Migrations completed"
fi

# 创建默认超级用户（可选，通过环境变量控制）
if [ "$CREATE_SUPERUSER" = "true" ] && [ -n "$SUPERUSER_EMAIL" ] && [ -n "$SUPERUSER_PASSWORD" ]; then
  echo "👤 Creating superuser..."
  python -c "
from database import engine
from models.user import User
from sqlmodel import Session, select
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=['bcrypt'], deprecated='auto')

with Session(engine) as session:
    existing = session.exec(select(User).where(User.email == '$SUPERUSER_EMAIL')).first()
    if not existing:
        user = User(
            email='$SUPERUSER_EMAIL',
            hashed_password=pwd_context.hash('$SUPERUSER_PASSWORD'),
            nickname='Admin',
            role='admin',
            is_active=True
        )
        session.add(user)
        session.commit()
        print('✅ Superuser created')
    else:
        print('ℹ️ Superuser already exists')
"
fi

echo "🎯 Starting application..."
exec "$@"