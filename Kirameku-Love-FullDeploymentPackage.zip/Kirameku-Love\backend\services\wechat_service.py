"""
微信头像获取服务
通过微信开放平台 API 根据微信号获取头像 URL
"""
import httpx
from config import settings


async def fetch_avatar_by_wechat_id(wechat_id: str) -> dict:
    """
    通过微信开放平台获取用户头像
    需要配置 WECHAT_APPID 和 WECHAT_SECRET

    注意：实际微信开放平台 API 并不直接支持通过微信号查询头像，
    这里使用微信开放平台的 unionid 机制作为替代方案。

    替代方案：
    1. 用户通过微信登录授权获取 openid/unionid
    2. 通过 unionid 查询用户信息（包括头像）

    此函数为示例实现，实际生产环境建议使用微信开放平台的完整授权流程。
    """
    if not settings.WECHAT_APPID or not settings.WECHAT_SECRET:
        raise Exception("微信配置缺失：请在 .env 中配置 WECHAT_APPID 和 WECHAT_SECRET")

    # 获取 access_token
    token_url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={settings.WECHAT_APPID}&secret={settings.WECHAT_SECRET}"

    async with httpx.AsyncClient() as client:
        # Step 1: 获取 access_token
        token_resp = await client.get(token_url)
        token_data = token_resp.json()
        if "access_token" not in token_data:
            raise Exception(f"获取微信 access_token 失败: {token_data}")

        access_token = token_data["access_token"]

        # Step 2: 尝试获取用户信息（这里是一个示例，实际需要通过 unionid 查询）
        # 微信开放平台没有直接的"通过微信号查头像"API
        # 实际方案：
        # - 用户微信授权登录 -> 获取 unionid
        # - 通过 unionid 关联查询用户表中的头像
        #
        # 下面返回一个占位响应，实际实现需要结合微信登录流程
        user_info = {
            "wechat_id": wechat_id,
            "avatar_url": "",  # 需要从微信授权流程中获取
            "nickname": "",
            "message": "请通过微信授权登录获取头像，或通过后台手动上传头像"
        }

        return user_info


async def get_wechat_user_info(unionid: str) -> dict:
    """
    通过 unionid 获取微信用户信息（包括头像）
    需要用户在微信授权登录流程中获取
    """
    if not settings.WECHAT_APPID or not settings.WECHAT_SECRET:
        raise Exception("微信配置缺失：请在 .env 中配置 WECHAT_APPID 和 WECHAT_SECRET")

    token_url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={settings.WECHAT_APPID}&secret={settings.WECHAT_SECRET}"

    async with httpx.AsyncClient() as client:
        token_resp = await client.get(token_url)
        token_data = token_resp.json()
        if "access_token" not in token_data:
            raise Exception(f"获取微信 access_token 失败: {token_data}")

        access_token = token_data["access_token"]

        # 获取用户信息
        userinfo_url = f"https://api.weixin.qq.com/sns/userinfo?access_token={access_token}&openid={unionid}&lang=zh_CN"
        user_resp = await client.get(userinfo_url)
        user_data = user_resp.json()

        if "avatar_url" not in user_data:
            raise Exception(f"获取微信用户信息失败: {user_data}")

        return {
            "wechat_id": unionid,
            "avatar_url": user_data.get("avatar_url", ""),
            "nickname": user_data.get("nickname", ""),
        }
