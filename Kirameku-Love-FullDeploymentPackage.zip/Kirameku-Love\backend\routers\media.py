"""
媒体路由 - 图片/视频上传
"""
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlmodel import Session, select
from typing import List
from fastapi import Form

from database import get_db
from models.media import RecordMedia
from models.lovelog import LoveRecord
from services.media_service import upload_file, get_file_url
from schemas import RecordMediaCreate, RecordMediaResponse

router = APIRouter()


@router.post("/upload")
async def upload_media(
    files: List[UploadFile] = File(...),
    record_id: int = Form(...),
    db: Session = Depends(get_db),
):
    """
    上传媒体文件（图片/视频）到指定记录
    支持多文件上传，使用 FormData
    """
    # 验证记录存在
    record = db.get(LoveRecord, record_id)
    if not record:
        raise HTTPException(status_code=404, detail="记录不存在")

    results = []
    for file in files:
        # 验证文件类型
        if not file.filename:
            continue

        ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
        valid_image_exts = {"jpg", "jpeg", "png", "gif", "webp", "bmp"}
        valid_video_exts = {"mp4", "webm", "mov", "avi"}

        if ext in valid_image_exts:
            media_type = "image"
        elif ext in valid_video_exts:
            media_type = "video"
        else:
            raise HTTPException(status_code=400, detail=f"不支持的文件类型: .{ext}")

        # 上传文件
        relative_path = upload_file(file, sub_dir="record_media")
        media_url = get_file_url(relative_path)

        # 创建记录媒体
        media = RecordMedia(
            record_id=record_id,
            media_type=media_type,
            media_url=media_url,
            caption=file.filename or "",
            sort_order=len(results),
        )
        db.add(media)
        db.commit()
        db.refresh(media)

        results.append(RecordMediaResponse.model_validate(media))

    return {"uploaded": len(results), "media": results}


@router.get("/record/{record_id}", response_model=List[RecordMediaResponse])
def list_media_for_record(record_id: int, db: Session = Depends(get_db)):
    """获取某条记录的所有媒体"""
    media_list = db.exec(
        select(RecordMedia)
        .where(RecordMedia.record_id == record_id)
        .order_by(RecordMedia.sort_order)
    ).all()
    return [RecordMediaResponse.model_validate(m) for m in media_list]


@router.delete("/{media_id}")
def delete_media(media_id: int, db: Session = Depends(get_db)):
    """删除媒体（仅管理员）"""
    media = db.get(RecordMedia, media_id)
    if not media:
        raise HTTPException(status_code=404, detail="媒体不存在")
    db.delete(media)
    db.commit()
    return {"message": "媒体已删除"}
