import './globals.css';

export const metadata = {
  title: '我们的恋爱记录',
  description: '记录我们的甜蜜时光',
};

export default function RootLayout({ children }) {
  return (
    <html lang="zh-CN">
      <body className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-red-50 antialiased">
        {children}
      </body>
    </html>
  );
}
