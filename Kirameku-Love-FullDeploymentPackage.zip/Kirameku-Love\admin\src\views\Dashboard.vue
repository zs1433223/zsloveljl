<template>
  <div class="dashboard-container">
    <el-card shadow="hover" class="card">
      <template #header>
        <div class="card-header">
          <span>📊 今日数据概览</span>
        </div>
      </template>
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <el-statistic
          title="新增记录"
          :value="todayRecords"
          :precision="0"
          :suffix="''"
          :value-style="{ color: '#ff3366' }"
        />
        <el-statistic
          title="新增评论"
          :value="todayComments"
          :precision="0"
          :suffix="''"
          :value-style="{ color: '#ff6699' }"
        />
        <el-statistic
          title="新增用户"
          :value="todayUsers"
          :precision="0"
          :suffix="''"
          :value-style="{ color: '#ff99cc' }"
        />
        <el-statistic
          title="访问量"
          :value="todayViews"
          :precision="0"
          :suffix="''"
          :value-style="{ color: '#ffccff' }"
        />
      </div>
    </el-card>

    <div class="charts-container">
      <el-card shadow="hover" class="chart-card">
        <template #header>
          <div class="card-header">
            <span>📈 记录趋势</span>
          </div>
        </template>
        <div ref="chartRef" class="chart" style="height: 300px;"></div>
      </el-card>

      <el-card shadow="hover" class="chart-card">
        <template #header>
          <div class="card-header">
            <span>🔥 热门记录</span>
          </div>
        </template>
        <el-table :data="topRecords" style="width: 100%" stripe>
          <el-table-column prop="title" label="标题" min-width="150" />
          <el-table-column prop="views" label="浏览量" sortable />
          <el-table-column prop="likes" label="点赞数" sortable />
          <el-table-column prop="created_at" label="创建时间" sortable />
        </el-table>
      </el-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { getDashboardData } from '@/utils/api'
import * as echarts from 'echarts'

const route = useRoute()

// 数据
const todayRecords = ref(0)
const todayComments = ref(0)
const todayUsers = ref(0)
const todayViews = ref(0)
const topRecords = ref([])

// 图表实例
const chartRef = ref(null)
let chartInstance: echarts.ECharts | null = null

// 获取仪表盘数据
const fetchData = async () => {
  try {
    const res = await getDashboardData()
    todayRecords.value = res.today_records
    todayComments.value = res.today_comments
    todayUsers.value = res.today_users
    todayViews.value = res.today_views
    topRecords.value = res.top_records
  } catch (e) {
    ElMessage.error('获取数据失败')
  }
}

// 初始化图表
const initChart = () => {
  if (!chartRef.value) return

  chartInstance = echarts.init(chartRef.value)

  const option = {
    tooltip: {
      trigger: 'axis',
      formatter: '{b} <br/> {a}: {c}'
    },
    legend: {
      data: ['记录数', '评论数', '用户数']
    },
    xAxis: {
      type: 'category',
      data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: '记录数',
        type: 'line',
        stack: '总量',
        areaStyle: {},
        emphasis: {
          focus: 'series'
        },
        data: [120, 132, 101, 134, 90, 230, 210]
      },
      {
        name: '评论数',
        type: 'line',
        stack: '总量',
        areaStyle: {},
        emphasis: {
          focus: 'series'
        },
        data: [220, 182, 191, 234, 290, 330, 310]
      },
      {
        name: '用户数',
        type: 'line',
        stack: '总量',
        areaStyle: {},
        emphasis: {
          focus: 'series'
        },
        data: [150, 232, 201, 154, 190, 330, 410]
      }
    ]
  }

  chartInstance.setOption(option)
}

onMounted(async () => {
  await fetchData()
  initChart()
})

onUnmounted(() => {
  if (chartInstance) {
    chartInstance.dispose()
    chartInstance = null
  }
})
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
}

.card {
  margin-bottom: 20px;
}

.card-header {
  font-size: 16px;
  font-weight: bold;
  color: #ff3366;
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
}

.charts-container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
}

.chart-card {
  height: 300px;
}

.chart {
  width: 100%;
  height: 100%;
}
</style>
