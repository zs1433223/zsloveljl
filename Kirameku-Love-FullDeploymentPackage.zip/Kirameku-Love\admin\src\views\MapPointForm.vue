<template>
  <div class="map-point-form-container">
    <el-card shadow="hover">
      <template #header>
        <div class="card-header">
          <span>{{ isEdit ? '编辑地图点位' : '新建地图点位' }}</span>
        </div>
      </template>

      <el-form
        ref="formRef"
        :model="form"
        :rules="rules"
        label-width="120px"
        label-position="right"
        style="width: 100%; max-width: 800px;"
      >
        <!-- 基本信息 -->
        <div class="form-section">
          <h4>基本信息</h4>
          
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="点位名称" prop="name">
                <el-input v-model="form.name" placeholder="请输入点位名称" maxlength="100" />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="点位类型" prop="point_type">
                <el-select v-model="form.point_type" placeholder="请选择类型" style="width: 100%">
                  <el-option label="约会地点" value="date" />
                  <el-option label="旅行足迹" value="travel" />
                  <el-option label="纪念地" value="anniversary" />
                  <el-option label="其他" value="other" />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>

          <el-form-item label="描述" prop="description">
            <el-input
              v-model="form.description"
              type="textarea"
              :rows="3"
              placeholder="请输入描述信息"
              maxlength="500"
              show-word-limit
            />
          </el-form-item>

          <!-- 地理位置 -->
          <h4 style="margin-top: 20px;">地理位置</h4>
          
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="经度" prop="longitude">
                <el-input-number
                  v-model="form.longitude"
                  :precision="6"
                  :step="0.000001"
                  :controls="false"
                  placeholder="请输入经度"
                  @blur="validateCoordinate"
                />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="纬度" prop="latitude">
                <el-input-number
                  v-model="form.latitude"
                  :precision="6"
                  :step="0.000001"
                  :controls="false"
                  placeholder="请输入纬度"
                  @blur="validateCoordinate"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="城市" prop="city">
                <el-input v-model="form.city" placeholder="请输入城市" maxlength="50" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="省份" prop="province">
                <el-input v-model="form.province" placeholder="请输入省份" maxlength="50" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="国家" prop="country">
                <el-input v-model="form.country" placeholder="请输入国家" maxlength="50" />
              </el-form-item>
            </el-col>
          </el-row>

          <el-row :gutter="20" style="margin-top: 10px;">
            <el-col :span="12">
              <el-form-item label="排序" prop="sort_order">
                <el-input-number v-model="form.sort_order" :min="0" :controls="false" placeholder="排序值" />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="状态" prop="status">
                <el-select v-model="form.status" placeholder="请选择状态" style="width: 100%">
                  <el-option label="已发布" value="published" />
                  <el-option label="草稿" value="draft" />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </div>

        <!-- 封面图 -->
        <div class="form-section" style="margin-top: 24px;">
          <h4>封面图片</h4>
          <el-form-item label="封面图" prop="cover_image">
            <div class="image-upload">
              <el-upload
                class="upload-demo"
                action="/api/media/upload"
                :headers="{ Authorization: 'Bearer ' + localStorage.getItem('token') }"
                :on-success="handleCoverUploadSuccess"
                :before-upload="beforeImageUpload"
                :auto-upload="true"
                list-type="picture-card"
                :limit="1"
                :on-exceed="handleExceed"
              >
                <img v-if="form.cover_image" :src="form.cover_image" class="el-upload-list__item-thumbnail" />
                <i v-else class="el-icon-plus upload-icon"></i>
              </el-upload>
              <div class="upload-tip">建议尺寸：400x300，支持 JPG/PNG，不超过 5MB</div>
            </div>
          </el-form-item>
        </div>

        <!-- 相册 -->
        <div class="form-section" style="margin-top: 24px;">
          <h4>相册图片</h4>
          <el-form-item label="相册" prop="photos">
            <el-upload
              class="upload-demo"
              action="/api/media/upload"
              :headers="{ Authorization: 'Bearer ' + localStorage.getItem('token') }"
              :on-success="handlePhotosUploadSuccess"
              :before-upload="beforeImageUpload"
              :auto-upload="true"
              list-type="picture-card"
              :limit="9"
              :on-exceed="handleExceed"
              :file-list="photoFileList"
            >
              <i class="el-icon-plus upload-icon"></i>
            </el-upload>
            <div class="upload-tip">最多上传 9 张图片，支持 JPG/PNG，单张不超过 5MB</div>
          </el-form-item>
        </div>

        <!-- 视频 -->
        <div class="form-section" style="margin-top: 24px;">
          <h4>视频</h4>
          <el-form-item label="视频" prop="videos">
            <el-upload
              class="upload-demo"
              action="/api/media/upload"
              :headers="{ Authorization: 'Bearer ' + localStorage.getItem('token') }"
              :on-success="handleVideosUploadSuccess"
              :before-upload="beforeVideoUpload"
              :auto-upload="true"
              list-type="picture-card"
              :limit="3"
              :on-exceed="handleExceed"
              :file-list="videoFileList"
            >
              <i class="el-icon-video-play upload-icon" style="font-size: 28px; color: #909399;"></i>
            </el-upload>
            <div class="upload-tip">最多上传 3 个视频，支持 MP4/MOV，单个不超过 50MB</div>
          </el-form-item>
        </div>

        <!-- 操作按钮 -->
        <div class="form-actions">
          <el-button @click="handleCancel">取消</el-button>
          <el-button type="primary" @click="handleSubmit">保存</el-button>
        </div>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getMapPoint, createMapPoint, updateMapPoint } from '@/utils/api'

const router = useRouter()
const route = useRoute()

const formRef = ref()
const isEdit = ref(false)
const mapPointId = ref<number | null>(null)

const photoFileList = ref<any[]>([])
const videoFileList = ref<any[]>([])

const form = reactive({
  name: '',
  description: '',
  longitude: 0,
  latitude: 0,
  city: '',
  province: '',
  country: 'China',
  point_type: 'date',
  cover_image: '',
  photos: [] as string[],
  videos: [] as string[],
  sort_order: 0,
  status: 'published',
})

const rules = reactive({
  name: [{ required: true, message: '请输入点位名称', trigger: 'blur' }],
  longitude: [
    { required: true, message: '请输入经度', trigger: 'blur' },
    { type: 'number', min: -180, max: 180, message: '经度范围：-180 到 180', trigger: 'blur' },
  ],
  latitude: [
    { required: true, message: '请输入纬度', trigger: 'blur' },
    { type: 'number', min: -90, max: 90, message: '纬度范围：-90 到 90', trigger: 'blur' },
  ],
  point_type: [{ required: true, message: '请选择点位类型', trigger: 'change' }],
  status: [{ required: true, message: '请选择状态', trigger: 'change' }],
})

// 验证坐标
const validateCoordinate = () => {
  if (form.longitude < -180 || form.longitude > 180) {
    ElMessage.warning('经度范围：-180 到 180')
    form.longitude = Math.max(-180, Math.min(180, form.longitude))
  }
  if (form.latitude < -90 || form.latitude > 90) {
    ElMessage.warning('纬度范围：-90 到 90')
    form.latitude = Math.max(-90, Math.min(90, form.latitude))
  }
}

// 图片上传前校验
const beforeImageUpload = (file: File): boolean => {
  const isJPG = file.type === 'image/jpeg'
  const isPNG = file.type === 'image/png'
  const isLt5M = file.size / 1024 / 1024 < 5

  if (!isJPG && !isPNG) {
    ElMessage.error('上传图片只能是 JPG/PNG 格式!')
    return false
  }
  if (!isLt5M) {
    ElMessage.error('上传图片大小不能超过 5MB!')
    return false
  }
  return true
}

// 视频上传前校验
const beforeVideoUpload = (file: File): boolean => {
  const isMP4 = file.type === 'video/mp4'
  const isMOV = file.type === 'video/quicktime'
  const isLt50M = file.size / 1024 / 1024 < 50

  if (!isMP4 && !isMOV) {
    ElMessage.error('上传视频只能是 MP4/MOV 格式!')
    return false
  }
  if (!isLt50M) {
    ElMessage.error('上传视频大小不能超过 50MB!')
    return false
  }
  return true
}

// 上传超限处理
const handleExceed = (files: File[], fileList: File[]) => {
  ElMessage.warning(`最多只能上传 ${fileList.length} 个文件`)
}

// 封面上传成功
const handleCoverUploadSuccess = (response: any) => {
  if (response.code === 200 && response.data) {
    form.cover_image = response.data.url
    ElMessage.success('封面上传成功')
  } else {
    ElMessage.error(response.message || '封面上传失败')
  }
}

// 相册上传成功
const handlePhotosUploadSuccess = (response: any, uploadFile: any) => {
  if (response.code === 200 && response.data) {
    form.photos.push(response.data.url)
    photoFileList.value = photoFileList.value.map(f => f.uid === uploadFile.uid ? { ...f, url: response.data.url } : f)
    ElMessage.success('图片上传成功')
  } else {
    ElMessage.error(response.message || '图片上传失败')
  }
}

// 视频上传成功
const handleVideosUploadSuccess = (response: any, uploadFile: any) => {
  if (response.code === 200 && response.data) {
    form.videos.push(response.data.url)
    videoFileList.value = videoFileList.value.map(f => f.uid === uploadFile.uid ? { ...f, url: response.data.url } : f)
    ElMessage.success('视频上传成功')
  } else {
    ElMessage.error(response.message || '视频上传失败')
  }
}

// 加载编辑数据
const loadMapPoint = async () => {
  const id = route.params.id
  if (id) {
    isEdit.value = true
    mapPointId.value = Number(id)
    try {
      const res = await getMapPoint(mapPointId.value)
      form.name = res.name
      form.description = res.description
      form.longitude = res.longitude
      form.latitude = res.latitude
      form.city = res.city
      form.province = res.province
      form.country = res.country
      form.point_type = res.point_type
      form.cover_image = res.cover_image
      form.photos = res.photos || []
      form.videos = res.videos || []
      form.sort_order = res.sort_order
      form.status = res.status

      // 构建文件列表用于显示
      photoFileList.value = form.photos.map((url, index) => ({
        uid: `photo-${index}`,
        name: `photo-${index}.jpg`,
        url,
        status: 'success',
      }))
      videoFileList.value = form.videos.map((url, index) => ({
        uid: `video-${index}`,
        name: `video-${index}.mp4`,
        url,
        status: 'success',
      }))
    } catch (e) {
      ElMessage.error('加载点位详情失败')
      router.push('/map-points')
    }
  }
}

// 提交表单
const handleSubmit = async () => {
  try {
    await formRef.value?.validate()
  } catch (e) {
    return
  }

  const loading = ElMessage.loading({ message: '保存中...' })
  try {
    if (isEdit.value && mapPointId.value) {
      await updateMapPoint(mapPointId.value, form)
      ElMessage.success('更新成功')
    } else {
      await createMapPoint(form)
      ElMessage.success('创建成功')
    }
    router.push('/map-points')
  } catch (e: any) {
    ElMessage.error(e.response?.data?.detail || '保存失败')
  } finally {
    loading.close()
  }
}

// 取消
const handleCancel = () => {
  router.push('/map-points')
}

// 监听路由变化
watch(() => route.params.id, (newId) => {
  if (newId) {
    loadMapPoint()
  } else {
    // 重置表单
    Object.assign(form, {
      name: '',
      description: '',
      longitude: 0,
      latitude: 0,
      city: '',
      province: '',
      country: 'China',
      point_type: 'date',
      cover_image: '',
      photos: [],
      videos: [],
      sort_order: 0,
      status: 'published',
    })
    photoFileList.value = []
    videoFileList.value = []
  }
}, { immediate: true })

onMounted(() => {
  if (route.params.id) {
    loadMapPoint()
  }
})
</script>

<style scoped>
.map-point-form-container {
  padding: 20px;
}

.form-section h4 {
  margin: 0 0 16px;
  padding-bottom: 8px;
  border-bottom: 1px solid #ebeef5;
  color: #303133;
  font-size: 16px;
  font-weight: 600;
}

.image-upload {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.upload-icon {
  font-size: 28px;
  color: #909399;
}

.upload-tip {
  font-size: 12px;
  color: #909399;
}

.upload-demo {
  width: 100%;
}

.el-upload-list__item {
  width: 100px !important;
  height: 100px !important;
}

.form-actions {
  margin-top: 30px;
  padding-top: 20px;
  border-top: 1px solid #ebeef5;
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}
</style>