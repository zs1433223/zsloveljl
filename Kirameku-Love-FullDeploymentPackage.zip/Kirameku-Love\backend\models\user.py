"""
用户模型
"""
from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import datetime


class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(unique=True, max_length=50)
    hashed_password: str = Field(max_length=128)
    nickname: str = Field(default="", max_length=50)
    avatar: str = Field(default="", max_length=500)
    wechat_id: str = Field(default="", max_length=100)
    email: str = Field(default="", max_length=100)
    role: str = Field(default="user", max_length=20)  # user, admin
    bio: str = Field(default="", max_length=500)
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
