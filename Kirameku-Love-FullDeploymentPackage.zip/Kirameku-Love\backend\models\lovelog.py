"""
恋爱记录模型
"""
from sqlmodel import SQLModel, Field
from typing import Optional, List
from datetime import date, datetime


class LoveRecord(SQLModel, table=True):
    __tablename__ = "loverecords"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str = Field(max_length=200)
    content: str = Field(default="")
    record_date: date
    is_private: bool = Field(default=False)
    status: str = Field(default="published", max_length=20)  # published, draft
    views: int = Field(default=0)
    likes: int = Field(default=0)
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
